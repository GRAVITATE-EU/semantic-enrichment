soton_corenlp project
=====================

soton_corenlppy is a Python core NLP library that is built upon NLTK. It handles text pre-processing, tokenization (word and sentence) and Parts Of Speech (POS) tagging. TreeTagger and Stanford POS Tagger are supported.

soton_corenlppy is used by the projects geoparsepy, openiepy and lixicopy.

soton_corenlppy works with Python 2.7 and has been tested on Windows 10, Windows 2012 Server, Ubuntu 14.04 LTS and Ubuntu 16.04 LTS.

Feature suggestions and/or bug reports can be sent to {soton_corenlppy}@it-innovation.soton.ac.uk. We do not however offer any software support beyond the examples and API documentation already provided.


soton_corenlppy user documentation
-----------------------------
https://pythonhosted.org/soton_corenlppy/readme.html


soton_corenlppy API documentation
----------------------------
https://pythonhosted.org/soton_corenlppy/index.html

The software is copyright 2017 University of Southampton IT Innovation Centre, UK (http://www.it-innovation.soton.ac.uk). It was created over a 5 year period under EU FP7 projects TRIDEC (grant agreement number 258723), REVEAL (grant agreement number 610928) and EU H2020 project GRAVITATE (grant agreement number 665155). This software can only be used for research, education or evaluation purposes. A free commercial license is available on request to {soton_corenlppy}@it-innovation.soton.ac.uk. The University of Southampton IT Innovation Centre is open to discussions regarding collaboration in future research projects relating to this work.


soton_corenlppy license
----------------------------
https://pythonhosted.org/soton_corenlppy/license.html


Python libs needed
------------------
Python libs: nltk >= 3.2, ,setuptools >= 20


