'''
/////////////////////////////////////////////////////////////////////////
//
// \xa9 University of Southampton IT Innovation, 2014
//
// Copyright in this software belongs to IT Innovation Centre of
// Gamma House, Enterprise Road, Southampton SO16 7NS, UK.
//
// This software may not be used, sold, licensed, transferred, copied
// or reproduced in whole or in part in any manner or form or in or
// on any media by any person other than in accordance with the terms
// of the Licence Agreement supplied with the software, or otherwise
// without the prior written consent of the copyright owners.
//
// This software is distributed WITHOUT ANY WARRANTY, without even the
// implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE, except where stated in the Licence Agreement supplied with
// the software.
//
//	Created By :	Vadims Krivcovs
//	Created Date :	2014/07/16
//	Created for Project:	REVEAL
//
/////////////////////////////////////////////////////////////////////////
//
// Dependencies: None
//
/////////////////////////////////////////////////////////////////////////
'''

# !/usr/bin/env python

"""
Social media response JSON parser class
- detect social media type based on json objects object
- detect timestamps of all known social media types (from JSON objects) and return parsed ISO 8601 formatted UTC time 
- convert json encoded strings to json objects
- sort list of json objects based on timestamp values (social media type can be automatically detected and based on that timestamp value
  will be automatically extracted)
- get author of social media type (social media type can be automatically detected)
- get geo tag (if exist) from json object (social media type can be automatically detected)
"""

import sys, json, datetime, time, logging, os, urllib, codecs
import time_helper

#
# Social media json object handler helper class
#
class SocialMediaParser( object ) :
	#
	# constructor
	# logger - reference to the logger instance (default None)
	# Exception: thrown if logger setup fails
	#
	def __init__( self, logger = None ) :
		# setup logger
		if logger == None :
			self.logger = logging.getLogger()
		else :
			self.logger = logger
	
	
	#
	# parse social media object and return parsed(based on social media type) timestamp datetime object from it (e.g. ISO 8601 formatted UTC timestamp)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: return ISO 8601 formatted UTC datetime object (format: yyyy-mm-ddThh:mm:ss+zz:zz) (datetime)
	# e.g. 
	#   2014-07-16T16:00:00+00:00
	# Exception: thrown if social media json object (dict or string) will be None, empty or invalid (not instance of dict or string)
	#
	def get_timestamp( self, objSocialMediaResponse, strSocialMediaType = None ) :
		# store json object variable that will be used to extract social media timestamp value
		jsonObject = None

		# store ISO 8601 formatted UTC timestamp variable
		dateTimeUTC = None

		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse

		# double check if the jsonObject is none or empty
		if jsonObject == None or len( jsonObject ) == 0 :
			raise Exception( 'json object can not be none or empty' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )

		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )

		# check if json object is twitter tweet and try to get timestamp value from it
		if strSocialMediaType == 'twitter' :
			# handle twitter time-stamps
			if 'created_at' in jsonObject :
				strTimestamp = jsonObject[ 'created_at' ]
				if strTimestamp[-5] != ' ' :
					# parse the twitter date string (note %z is not supported so parse offset the hard way) into a datetime object
					nOffsetHours = int(strTimestamp[-5:-2])
					nOffsetMinutes = int(strTimestamp[-2:])
					strDateLocal = strTimestamp[:-6]
					ddate = datetime.datetime.strptime( strDateLocal, '%a, %d %b %Y %H:%M:%S' )
				else :
					# parse the twitter date string (note %z is not supported so parse offset the hard way) into a datetime object
					nOffsetHours = int(strTimestamp[-10:-7])
					nOffsetMinutes = int(strTimestamp[-7:-5])
					strDateLocal = strTimestamp[:-11] +  strTimestamp[-5:]
					ddate = datetime.datetime.strptime( strDateLocal, '%a %b %d %H:%M:%S %Y' )
				utc = time_helper.UTC()
				dateTimeUTC = ( ddate - datetime.timedelta( minutes=nOffsetMinutes, hours=nOffsetHours ) ).replace( tzinfo=utc )
			else :
				self.logger.debug( 'tweet timestamp (e.g. created_at) was not found in (' + repr( jsonObject ) + ')' )

		# check if json object is youtube item and try to get timestamp value from it
		# note: youtube timestamp is RFC 3339 (e.g. 1970-01-01T00:00:00Z)
		elif strSocialMediaType == 'youtube' :
			# handle youtube timestamps (e.g. 2014-03-12T22:12:02.000Z)
			if 'publishedAt' in jsonObject[ 'snippet' ] :
				strTimestamp = jsonObject[ 'snippet' ][ 'publishedAt' ]
				
				# check if the timestamp values is UTC ('Z' should be specified in the end of the timestamp string)
				if strTimestamp[-1:] == 'Z' :
					strTimestampNoTimeZone = strTimestamp[:-1]

					# convert time
					# note: check if microseconds were specified in the timestamp 
					if strTimestampNoTimeZone[19:20] == '.' and len( strTimestampNoTimeZone[20:] ) != 0 :
						# parse the timestamp value including microseconds, e.g. 2014-03-12T22:12:02.123
						# note: if microseconds will be equal to 0 (e.g. .000) then they will be automatically removed
						# by the parser
						dateResult = datetime.datetime.strptime( strTimestampNoTimeZone, '%Y-%m-%dT%H:%M:%S.%f' )

					# parse the RFC 3339 timestamp value without microseconds
					else :
						dateResult = datetime.datetime.strptime( strTimestampNoTimeZone, '%Y-%m-%dT%H:%M:%S' )

					# since its is a UTC timestamp add UTC timezone object to the parsed datetime obhect
					utc = time_helper.UTC()
					dateTimeUTC = dateResult.replace( tzinfo=utc )
			else :
				self.logger.debug( 'youtube item timestamp (e.g. publishedAt) was not found in (' + repr( jsonObject ) + ')' )
				
		# check if json object is instagram media item and try to get timestamp value from it
		# note: instagram timestamp is unix timestamp (note: unix timestamp is created by using UTC timezone)
		elif strSocialMediaType == 'instagram' :
			if 'created_time' in jsonObject :
				strUnixTimestamp = jsonObject[ 'created_time' ]

				# convert unix timestamp to date string representation (e.g. format %Y-%m-%d %H:%M:%S)
				strTimeConverted = datetime.datetime.fromtimestamp( int( strUnixTimestamp ) ).strftime('%Y-%m-%d %H:%M:%S' )
				
				# create a datetime object from the above string
				ddate = datetime.datetime.strptime( strTimeConverted, '%Y-%m-%d %H:%M:%S' )
				
				# create utc timezone aware date
				dateTimeUTC = time_helper.convert_datetime_tz_iso( ddate )
			else :
				self.logger.debug( 'instagram media timestamp (e.g. created_time) was not found in (' + repr( jsonObject ) + ')' )

		# check if json object is foursquare venue 
		# note: there is no timestamps in foursquare venue response json therefore additional timestamp element(itinno:timestamp) will be added to the foursquare 
		# json result during the crawler process (e.g. foursquare venue search)
		# e.g.
		#   "itinno:timestamp" : " 2014-07-16T16:35:38+00:00" 
		elif strSocialMediaType == 'foursquare' :
			if 'itinno:timestamp' in jsonObject :
				strTimestamp = jsonObject[ 'itinno:timestamp' ]

				# parse datetime and create datetime object
				dateTimeUTC = time_helper.parse_iso_datetime( strTimestamp )
			else :
				self.logger.debug( 'foursquare venue media timestamp (e.g. itinno:timestamp) was not found in (' + repr( jsonObject ) + ')' )

		# check if facebook json item
		elif strSocialMediaType == 'facebook' :
			if 'created_time' in jsonObject :
				strTimestamp = jsonObject[ 'created_time' ]

				# facebook timestamp is in the format of 2015-11-09T22:00:00+0000 and it needs parsing in order to be used with time_helper library
				# i.e. format is with column with a colon delimeter e.g. from +0000 create +00:00
				strTimestamp = strTimestamp[:22] + ':' +  strTimestamp[22:]

				# parse datetime and create datetime object
				dateTimeUTC = time_helper.parse_iso_datetime( strTimestamp )

		# if social media will be unknown then return None
		else :
			dateTimeUTC = None

		# return datetime object
		return dateTimeUTC 
	
	
	#
	# parse social media object and return its author (based on social media type)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: author name with social media type prefix (str)
	# e.g. 
	#   author in twitter = '@screen name' 
	#   author in youtube = 'yt:channelId'
	#   author in instagram = 'in:username'
	#   author in facebook = 'fb:user name'
	#   foursquare = None (there is no author in foursquare venue)
	#
	def get_author( self, objSocialMediaResponse, strSocialMediaType = None ) :
		# store json object variable that will be used to extract social media author
		jsonObject = None

		# store author id variable (defaulted to None, NOT '' in order to match other function returns in this class)
		strAuthorId = None

		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse

		# double check if the jsonObject is none or empty
		if jsonObject == None or len( jsonObject ) == 0 :
			raise Exception( 'json object can not be none or empty' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )

		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )

		# check if json object is twitter tweet and try to get author id from it (e.g. screen_name)
		if strSocialMediaType == 'twitter' :
			# handle twitter screen name detection
			if 'user' in jsonObject :
				dictUser = jsonObject['user']

				# check the screen name
				if 'screen_name' in dictUser :
					strAuthorId = '@' + dictUser['screen_name']
				else :
					self.logger.debug( 'tweet user name (e.g. screen_name) was not found in (' + repr( jsonObject ) + ')' )
			else :
				self.logger.debug( 'tweet user (e.g. user) was not found in (' + repr( jsonObject ) + ')' )

		# check if json object is youtube item and try to get author id from it (e.g. channelId)
		elif strSocialMediaType == 'youtube' :
			# check the channelId
			if 'snippet' in jsonObject :
				dictSnippet = jsonObject['snippet']

				if 'channelId' in dictSnippet :
					strAuthorId = 'yt:' + dictSnippet['channelId']
				else :
					self.logger.debug( 'youtube item channelId (e.g. channelId) was not found in (' + repr( jsonObject ) + ')' )
			else :
				self.logger.debug( 'youtube item snippet (e.g. snippet) was not found in (' + repr( jsonObject ) + ')' )

		# check if json object is instagram media item and try to get author id from it (e.g. username)
		elif strSocialMediaType == 'instagram' :
			if 'user' in jsonObject :
				dictUser = jsonObject['user']

				# check the screen name
				if 'username' in dictUser :
					strAuthorId = 'in:' + dictUser['username']
				else :
					self.logger.debug( 'instagram media username (e.g. username) was not found in (' + repr( jsonObject ) + ')' )
			else :
				self.logger.debug( 'instagram media user (e.g. user) was not found in (' + repr( jsonObject ) + ')' )	

		# if facebook
		elif strSocialMediaType == 'facebook' :
			
			if 'from' in jsonObject :
				if 'name' in jsonObject['from'] :
					strAuthorId = 'fb:' + jsonObject['from']['name']

		# check if json object is foursquare venue 
		# note: there is not timestamps in foursquare venue response json, thefore None will be returned
		elif strSocialMediaType == 'foursquare' :
			strAuthorId = None
		# if social media will be unknown then return None
		else :
			strAuthorId = None

		# return author id
		return strAuthorId 

	#
	# parse social media object source URI
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: URI string
	#
	def get_source_uri( self, objSocialMediaResponse, strSocialMediaType = None ) :

		jsonObject = None
		strURI = ''
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )
		
		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :

			strUserScreenName = ''
			if 'user' in jsonObject :
				dictUser = jsonObject['user']
				if 'screen_name' in dictUser :
					strUserScreenName = dictUser['screen_name']

			if len(strUserScreenName) > 0 :
				strURI = 'https://twitter.com/' + strUserScreenName + '/status/' + jsonObject['id_str']

		elif strSocialMediaType == 'youtube' :

			strItemID = ''
			if 'id' in jsonObject :
				if 'videoId' in jsonObject['id'] :
					strItemID = jsonObject['id']['videoId']

			if len(strItemID) > 0 :
				strURI = 'https://youtube.com/watch?v=' + strItemID

		elif strSocialMediaType == 'instagram' :

			if 'link' in jsonObject :
				strURI = jsonObject['link']


		# TODO: check this one
		elif strSocialMediaType == 'foursquare' :

			# get venue id
			strVenueID = ''
			if 'id' in jsonObject :
				strVenueID = jsonObject['id']
			
			# get title
			strTitle = ''
			if 'name' in jsonObject :
				strTitle = jsonObject['name']
			
			# get source uri
			# note: part of the source uri need to be costructed based on venue name
			# e.g.
			# if venue name is 'the super pub', then part of the source uri should be 'the-super-pub' (https://foursquare.com/v/the-super-pub/<id of the super pub>)
			strSourceUriVenueName = ''
			if strTitle != None and len( strTitle ) > 0 :
				if ' ' in strTitle :
					listSourceNameParts = strTitle.split( ' ' )
					for strSourceNamePart in listSourceNameParts :
						strSourceUriVenueName = strSourceUriVenueName + strSourceNamePart + '-'
					if strSourceUriVenueName[-1:] == '-' :
						strSourceUriVenueName = strSourceUriVenueName[:-1]
				else :
					strSourceUriVenueName = strTitle
				strURI = 'https://foursquare.com/v/' + strSourceUriVenueName + '/' + strVenueID

		elif strSocialMediaType == 'facebook' :
			if 'permalink_url' in jsonObject :
				strURI = jsonObject['permalink_url']

		return strURI

	#
	# parse social media object author URI
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: URI string
	#
	def get_author_uri( self, objSocialMediaResponse, strSocialMediaType = None ) :

		jsonObject = None
		strURI = ''
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )
		
		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :

			strUserScreenName = ''
			if 'user' in jsonObject :
				dictUser = jsonObject['user']
				if 'screen_name' in dictUser :
					strUserScreenName = dictUser['screen_name']

			if len(strUserScreenName) > 0 :
				strURI = 'https://twitter.com/' + strUserScreenName

		elif strSocialMediaType == 'youtube' :

			strChannelID = ''
			dictSnippet = jsonObject['snippet']
			if 'channelId' in dictSnippet :
				strChannelID = dictSnippet['channelId']

			if len(strChannelID) > 0 :
				strURI = 'https://youtube.com/channel/' + strChannelID

		elif strSocialMediaType == 'instagram' :

			strUserName = ''
			if 'user' in jsonObject :
				if 'username' in jsonObject['user'] :
					strUserName = jsonObject['user']['username']

			if len(strUserName) > 0 :
				strURI = 'http://instagram.com/' + strUserName

		elif strSocialMediaType == 'foursquare' :

			# no author for venues as such (maybe use venue owner?)
			pass

		elif strSocialMediaType == 'facebook' :

			if 'from' in jsonObject :
				if 'id' in jsonObject['from'] :
					strURI = 'http://facebook.com/profile.php?id=' + jsonObject['from']['id']

		return strURI


	
	#
	# parse social media object and return its geo tag coordinates (if any)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: geo tag details (tuple)
	# e.g.
	# return tupple value = ( long, lat, POINT(long lat) )
	# - long = float
	# - lat = float
	# POINT(long lat) = string OpenGIS point 
	#
	def get_geotag( self, objSocialMediaResponse, strSocialMediaType = None ) :
		# store json object variable that will be used to extract social media geotag
		jsonObject = None
		
		# define geotag tuple variable
		tupleGeoTag = None
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )
		
		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :
			# handle twitter screen name detection
			if 'geo' in jsonObject :
				if jsonObject['geo'] != None :
					dictGeo = jsonObject['geo']
					
					# check the geo coordinates
					if 'coordinates' in dictGeo :
						listGeoCoordinates = dictGeo['coordinates']
						
						# check if the coordinates element is instance of list (e.g. twitter geo coordicates is a list of [lat,long])
						if isinstance( listGeoCoordinates, list ) :
							# get long and lat from the coordinates list
							# e.g. the coordinates in geo are represented in 'human readable' form (e.g. lat,lon)
							# therefore the long coordinate will be at position list[1] and lat at position list[0]
							# note: actual 'coordinates'(separate from geo) element is in geojson form (e.g. lon, lat)
							fLong = None
							fLat = None
							
							# try to get longitude and latitude from the geo coordinates element
							try :
								fLong =listGeoCoordinates[1]
								fLat = listGeoCoordinates[0]
							except :
								raise Exception( 'failed to read longitude and/or latitude from geo coordinates element (' + str( sys.exc_info()[1] ) + ')' )
							
							# construct geotag tupple
							tupleGeoTag = self.construct_geotag_tuple( fLong, fLat )
							
						else :
							self.logger.debug( 'tweet geo coordinates are invalid (must be instance of list, not' + type( listGeoCoordinates ) + ')' )
				
			else :
				self.logger.debug( 'tweet geo (e.g. geo) was not found in (' + repr( jsonObject ) + ')' )
		
		# check if json object is youtube
		# note: there is not geo location metadata in the youtube video result (the crawler will find the videos by the location,
		# but the location metadata is not included in the response!)
		elif strSocialMediaType == 'youtube' :
			tupleGeoTag = None
		
		# check if json object is instagram media item and try to get author id from it (e.g. username)
		elif strSocialMediaType == 'instagram' :
			if 'location' in jsonObject :
				dictLocation = jsonObject['location']

				# some instagram content will not have a geotag (location = null)
				if dictLocation != None :
				
					# define default longitude and latitude values
					fLong = None
					fLat = None
					
					# check the longitude value
					if 'longitude' in dictLocation :
						fLong = dictLocation['longitude']
					else :
						self.logger.debug( 'instagram media longitude (e.g. longitude) was not found in (' + repr( jsonObject ) + ')' )
					
					# check the latitude value
					if 'latitude' in dictLocation :
						fLat = dictLocation['latitude'] 
					else :
						self.logger.debug( 'instagram media latitude (e.g. latitude) was not found in (' + repr( jsonObject ) + ')' )
					
					# check if long and lat values are not None (only then construct the geotag tupple)
					if fLong is not None and fLat is not None :
						# construct geotag tupple
						tupleGeoTag = self.construct_geotag_tuple( fLong, fLat )
					else :
						self.logger.debug( 'longitude and/or latitude value can not be none' )

			else :
				self.logger.debug( 'instagram media location (e.g. location) was not found in (' + repr( jsonObject ) + ')' )	
		
		# check if json object is foursquare venue 
		elif strSocialMediaType == 'foursquare' :
			if 'location' in jsonObject :
				dictLocation = jsonObject['location']
				
				# define default longitude and latitude values
				fLong = None
				fLat = None
				
				# check the longitude value
				if 'lng' in dictLocation :
					fLong = dictLocation['lng']
				else :
					self.logger.debug( 'foursquare venue longitude (e.g. lng) was not found in (' + repr( jsonObject ) + ')' )
				
				# check the latitude value
				if 'lat' in dictLocation :
					fLat = dictLocation['lat'] 
				else :
					self.logger.debug( 'foursquare venue latitude (e.g. lat) was not found in (' + repr( jsonObject ) + ')' )
				
				# check if long and lat values are not None (only then construct the geotag tupple)
				if fLong is not None and fLat is not None :
					# finally construct geotag tupple
					tupleGeoTag = self.construct_geotag_tuple( fLong, fLat )
				else :
					self.logger.debug( 'longitude and/or latitude value can not be none' )
				
			else :
				self.logger.debug( 'foursquare venue location (e.g. location) was not found in (' + repr( jsonObject ) + ')' )
			
		# if social media will be unknown then return None
		else :
			# note: the default value is None anyway
			tupleGeoTag = None
		
		# return geo tag tuple
		return tupleGeoTag 
	
	#
	# parse social media object and return its links (web URIs and media URIs)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: list of URIs
	#
	def get_links( self, objSocialMediaResponse, strSocialMediaType = None ) :

		jsonObject = None
		listURIs = []
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )
		
		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :

			for strTypeBase in ['entities','extended_entities'] :
				if strTypeBase in jsonObject :
					# import links of all types (web links, photos, video) 
					# extended_entities can appear under entities I think
					for strTypeLink in ['urls','media','extended_entities'] :
						if strTypeLink in jsonObject[strTypeBase] :

							# check urls
							listDict = jsonObject[strTypeBase][strTypeLink]
							if listDict != None and len( listDict ) > 0 :
								for listEntry in listDict :

									# link itself (e.g. web link or twitter embedded photo)
									if 'expanded_url' in listEntry :
										if not listEntry['expanded_url'] in listURIs :
											listURIs.append( listEntry['expanded_url'] )
									elif 'url' in listEntry :
										if not listEntry['url'] in listURIs :
											listURIs.append( listEntry['url'] )

									# link to original media (e.g. video)
									if 'media_url' in listEntry :
										if not listEntry['media_url'] in listURIs :
											listURIs.append( listEntry['media_url'] )
									elif 'media_url_https' in listEntry :
										if not listEntry['media_url_https'] in listURIs :
											listURIs.append( listEntry['media_url_https'] )

		elif strSocialMediaType == 'youtube' :

			dictSnippet = jsonObject['snippet']

			# import default OR highest res thumbnail available
			if 'thumbnails' in dictSnippet :
				bFound = False
				if bFound == False and 'high' in dictSnippet['thumbnails'] :
					if 'url' in dictSnippet['thumbnails']['high'] :
						listURIs.append( dictSnippet['thumbnails']['high']['url'] )
						bFound = True
				if bFound == False and 'medium' in dictSnippet['thumbnails'] :
					if 'url' in dictSnippet['thumbnails']['medium'] :
						listURIs.append( dictSnippet['thumbnails']['medium']['url'] )
						bFound = True
				if bFound == False and 'default' in dictSnippet['thumbnails'] :
					if 'url' in dictSnippet['thumbnails']['default'] :
						listURIs.append( dictSnippet['thumbnails']['default']['url'] )
						bFound = True

		elif strSocialMediaType == 'instagram' :

			# import standard res OR highest res image available
			if 'images' in jsonObject :
				bFound = False
				if 'standard_resolution' in jsonObject['images'] :
					if 'url' in jsonObject['images']['standard_resolution'] :
						listURIs.append( jsonObject['images']['standard_resolution']['url'] )
						bFound = True
				if bFound == False and 'low_resolution' in jsonObject['images'] :
					if 'url' in jsonObject['images']['low_resolution'] :
						listURIs.append( jsonObject['images']['low_resolution']['url'] )
						bFound = True
				if bFound == False and 'thumbnail' in jsonObject['images'] :
					if 'url' in jsonObject['images']['thumbnail'] :
						listURIs.append( jsonObject['images']['thumbnail']['url'] )
						bFound = True

		elif strSocialMediaType == 'foursquare' :

			pass

		elif strSocialMediaType == 'facebook' :

			pass

		return listURIs

	#
	# parse social media object and return its thumbnail (or None if not available)
	# only known media type4s will support this (Twitter, YouTube, Instagram, Vine)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: URI (or None)
	#
	def get_thumbnail( self, objSocialMediaResponse, strSocialMediaType = None ) :

		jsonObject = None
		strThumbnail = None
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )
		
		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :

			# Twitter has no direct thumbnail (you can render use the sourceURI)
			pass

		elif strSocialMediaType == 'youtube' :

			dictSnippet = jsonObject['snippet']

			# use default image first, then medium and at last resort high res image URI
			if 'thumbnails' in dictSnippet :
				if strThumbnail == None and 'default' in dictSnippet['thumbnails'] :
					if 'url' in dictSnippet['thumbnails']['default'] :
						strThumbnail = dictSnippet['thumbnails']['default']['url']
				if strThumbnail == None and 'medium' in dictSnippet['thumbnails'] :
					if 'url' in dictSnippet['thumbnails']['medium'] :
						strThumbnail = dictSnippet['thumbnails']['medium']['url']
				if strThumbnail == None and 'high' in dictSnippet['thumbnails'] :
					if 'url' in dictSnippet['thumbnails']['high'] :
						strThumbnail = dictSnippet['thumbnails']['high']['url']

		elif strSocialMediaType == 'instagram' :

			# use default image first, then low and at last resort standard res image URI
			if 'images' in jsonObject :
				if strThumbnail == None and 'thumbnail' in jsonObject['images'] :
					if 'url' in jsonObject['images']['thumbnail'] :
						strThumbnail = jsonObject['images']['thumbnail']['url']
				if strThumbnail == None and 'low_resolution' in jsonObject['images'] :
					if 'url' in jsonObject['images']['low_resolution'] :
						strThumbnail = jsonObject['images']['low_resolution']['url']
				if strThumbnail == None and 'standard_resolution' in jsonObject['images'] :
					if 'url' in jsonObject['images']['standard_resolution'] :
						strThumbnail = jsonObject['images']['standard_resolution']['url']

		elif strSocialMediaType == 'foursquare' :

			pass

		return strThumbnail

	#
	# parse social media object and return its tags (tags, keywords, hashtags)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: list of URIs
	#
	def get_tags( self, objSocialMediaResponse, strSocialMediaType = None ) :

		jsonObject = None
		listTags = []
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )
		
		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :

			if 'entities' in jsonObject :
				if 'hashtags' in jsonObject['entities'] :
					listDict = jsonObject['entities']['hashtags']
					if listDict != None and len( listDict ) > 0 :
						for listEntry in listDict :
							listTags.append( listEntry['text'] )

		elif strSocialMediaType == 'youtube' :

			# no tags in youtube search response
			pass

		elif strSocialMediaType == 'instagram' :

			if 'tags' in jsonObject :
				listTempTags = jsonObject['tags']
				if listTempTags != None and len( listTempTags ) > 0 :
					for strTag in listTempTags :
						listTags.append( strTag )

		elif strSocialMediaType == 'foursquare' :

			pass

		elif strSocialMediaType == 'facebook' :

			pass

		return listTags

	#
	# parse social media object and return its user mentions (user entities)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: list of URIs
	#
	def get_user_mentions( self, objSocialMediaResponse, strSocialMediaType = None ) :

		jsonObject = None
		listUserMentions = []
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )
		
		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :

			if 'entities' in jsonObject :
				if 'user_mentions' in jsonObject['entities'] :
					listDict = jsonObject['entities']['user_mentions']
					if listDict != None and len( listDict ) > 0 :
						for listEntry in listDict :
							listUserMentions.append( listEntry['screen_name'] )

		elif strSocialMediaType == 'youtube' :

			# no user mentions in youtube search response
			pass

		elif strSocialMediaType == 'instagram' :

			# no user mentions in youtube search response
			pass

		elif strSocialMediaType == 'foursquare' :

			pass

		elif strSocialMediaType == 'facebook' :

			pass

		return listUserMentions

	#
	# parse social media object and return its text(tweet text, YT title + desc, Instagram title)
	# objSocialMediaResponse - social media response object (dict or str)
	# strSocialMediaType - optional string value that will indicate type of specified social media response json (e.g. twitter, youtube etc) (str)
	# Return: unicode string
	#
	def get_text( self, objSocialMediaResponse, strSocialMediaType = None ) :

		jsonObject = None
		strText = ''
		
		# check if the json object is instance of dict, if not try to convert json formatted string to json object
		if not isinstance( objSocialMediaResponse, dict ) :
			jsonObject = self.convert_to_json( objSocialMediaResponse )
		else :
			jsonObject = objSocialMediaResponse
		
		# double check if the jsonObject is none or empty
		if jsonObject == None :
			raise Exception( 'json object can not be none' )
		if not isinstance( jsonObject, dict ) :
			raise Exception( 'invalid json object (' + repr( jsonObject ) + ')' )
		
		# detect social media type using the json object
		# if the social media type was not specified as function parameter, then detect social media type from json object
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			strSocialMediaType = self.detect_social_media_type( jsonObject )

		# check if json object is twitter tweet and try to get geo details from it(if any) (e.g. geo)
		if strSocialMediaType == 'twitter' :

			strText = jsonObject['text']

		elif strSocialMediaType == 'youtube' :

			dictSnippet = jsonObject['snippet']

			# title
			strTitle = ''
			if 'title' in dictSnippet :
				strTitle = dictSnippet['title']

			# description
			strDescription = ''
			if 'description' in dictSnippet :
				strDescription = dictSnippet['description']

			strText = strTitle
			if len(strDescription) > 0 :
				if len(strText) > 0 :
					strText = strText + '\n'
				strText = strText + strDescription

		elif strSocialMediaType == 'instagram' :

			# get caption text
			if 'caption' in jsonObject :
				if jsonObject['caption'] != None :
					if 'text' in jsonObject['caption'] :
						strText = jsonObject['caption']['text']

		elif strSocialMediaType == 'foursquare' :

			# get name of venue (best guess for text)
			if 'name' in jsonObject :
				strText = jsonObject['name']

		elif strSocialMediaType == 'facebook' :

			if 'message' in jsonObject :
				strText = jsonObject['message']

		return unicode( strText )


	#
	# detect social media type based on passed json object
	# jsonObject - social media response object (dict or str)
	# Return: social media type, e.g. twitter, instagram etc (str)
	# Exception: thrown if fail to parse json object
	#
	def detect_social_media_type( self, jsonObject ) :
		# social media type variable that will be returned from the function
		strSocialMediaType = ''
		
		# check if the passed value is json object
		if not isinstance( jsonObject, dict ) :
			jsonObject = self.convert_to_json( jsonObject )
		
		# start detecting he social media type from the json object
		# check if json object is twitter tweet (e.g. on unique keys 'retweeted')
		if 'retweeted' in jsonObject  : 
			strSocialMediaType = 'twitter'

		# check if json object is youtube item (e.g. on unique keys 'snipper' and 'channelId'(e.g. in the snippet object))
		elif 'snippet' in jsonObject :
			strSocialMediaType = 'youtube'

		# check if json object is instagram media (e.g. on unique keys 'users_in_photo')
		elif 'users_in_photo' in jsonObject :
			strSocialMediaType = 'instagram'

		# check if json object is foursquare venue (e.g. on unique keys 'stats' and 'verified'(e.g. in the user profile settings)
		# note: 'stats and 'verified' returned in both compact and full venue response, other response fields are either optional or similar to other
		# social media types, e.g. id, name etc
		elif 'stats' in jsonObject and 'verified' in jsonObject :
			strSocialMediaType = 'foursquare'

		elif 'likes' in jsonObject :
			strSocialMediaType = 'facebook'

		else :
			strSocialMediaType = 'unknown'

		# return social media type result
		return strSocialMediaType
	
	
	#
	# helper function convert passed object to json (e.g. social media json encoded response string)
	# objSocialMediaResponse - social media response object (dict or str)
	# Return: json object
	# Exception: thrown if invalid json encoded string will be specified
	#
	def convert_to_json( self, objSocialMediaResponse ) :
		# store json object variable that will be returned from the function if all the checks will be successfully made
		jsonObject = None
		
		# check if passed object is instance of dict
		if isinstance( objSocialMediaResponse, dict ) :
			# dump json object to utf-8 encoded string (if the exception will be raised this will indicate that the json object
			# was not properly structured) 
			try :
				# create json encoded string from the object (to make sure that the json object can be properly parsed)
				strJSON = json.dumps( objSocialMediaResponse, encoding = 'utf-8' )
				
				# double check the json string value 
				if strJSON == None or len( strJSON ) == 0 :
					raise Exception( 'invalid json object is specified( ' + repr( objSocialMediaResponse ) + ')')
				
				# store jsonObject
				jsonObject = objSocialMediaResponse
			except :
				raise Exception( 'json dict object is invalid (' + str( sys.exc_info()[1] ) + ')' )
		# check if passed object is instance of string
		elif (isinstance( objSocialMediaResponse, str ) or isinstance( objSocialMediaResponse, unicode )) :
			try :
				# create json object from json encoded string
				jsonObject = json.loads( objSocialMediaResponse, encoding = 'utf-8' )
				
				# double check the json dict value 
				if jsonObject == None :
					raise Exception( 'json encoded string is invalid (' + str( sys.exc_info()[1] ) + ')' ) 
			except :
				raise Exception( 'json encoded string is invalid (' + str( sys.exc_info()[1] ) + ')' ) 
		else :
			raise Exception( 'passed object was not instance of dict or string : ' + str(type(jsonObject)) )
		
		# return json object if all the above checks pass
		return jsonObject
	
	'''

	# OLD stuff used by JDSS services and crawler

	#
	# sort list of social media objects based on its timestamp value (all timestamps will be automatically converted to the common
	# ISO 8601 formatted UTC datetime objects and will allow universal sorting for different social media json objects)
	# listSocialMediaObjects - list of social media json objects (list)
	# bReverse - boolean flag that will trigger reverse list sort (default False) (bool)
	# Return: sorted list of social media json objects (list)
	# Exception: thrown if list object checks (its instance and size) will fail
	#
	def sort_social_media_list( self, listSocialMediaObjects, bReverse = False ) :
		# define sorted social media list variable
		listSortedSocialMediaObjects = []

		if not isinstance( listSocialMediaObjects, list ) :
			raise Exception( 'invalid list of social media response objects was specified' )
		if listSocialMediaObjects == None or len( listSocialMediaObjects ) == 0 :
			raise Exception( 'list of social media response objects can not be none or empty' )

		# sort list of social media json items
		# note: special call will be made to sort_by_time callback function that will automatically detect social media type, detect its timestamp
		# value, convert it to ISO 8601 formatted datetime UTC object and return it for sorting
		listSortedSocialMediaObjects = sorted( listSocialMediaObjects, key=self.sort_by_time, reverse = bReverse )

		# return sorted list
		return listSortedSocialMediaObjects
	
	
	#
	# helper callback function that will automatically detect social media type, detect its timestamp, convert it to ISO 8601 formatted datetime UTC object
	# and return it for sorting
	# note: this method allows to to sort mixed type of the social media json objects with different timestamp formats because every single timestamp
	# will be converted to common ISO 8601 formatted UTC datetime and sorted based on that
	# jsonSocialMediaItem - social media json response object (dict)
	# 
	def sort_by_time( self, jsonSocialMediaItem ) :
		try :
			# get timestamp object from social media json object
			datetimeObject = self.get_timestamp( jsonSocialMediaItem )

			# return datetime object
			return datetimeObject
		except :
			# note: do not raise the exception here, just log error of the event as the exception will
			# stop the sorting function(e.g. it is not a good option to stop sorting in one of the json objects will be malformed and/or corrupted)
			self.logger.error( 'failed to get timestamp for (' + repr( jsonSocialMediaItem ) + ') (' + str( sys.exc_info()[1] ) + ')' )
	
	
	#
	# create OpenGIS point(string) using long and lat (this is just a helper method that will check/verify long and lat values 
	# and return formatted OpenGIS point)
	# note: the order is important in the OpenGIS point, e.g. POINT(long lat)
	# fLong - longitute value (float)
	# fLat - latitude value (float)
	# Exception: thrown if function fails to construct OpenGIS point string
	#
	def construct_opengis_point( self, fLong, fLat ) :
		# define OpenGIS point string variable
		strOpenGISPoint = None
		
		# check if the longitude and latitude values are not None, as well as have valid format
		if fLong == None :
			raise Exception( 'longitude value can not be none' )
		if fLat == None :
			raise Exception( 'latitude value can not be none' )
		
		# construct OpenGIS point string
		strOpenGISPoint = "POINT({:0.12g} {:0.12g})".format( float( fLong ), float( fLat ) )
		
		# return OpenGIS point
		return strOpenGISPoint
	
	
	#
	# helper method that will create getotag tupple using long and lat
	# note: the order is important in the OpenGIS point, e.g. POINT(long lat)
	# fLong - longitute value (float)
	# fLat - latitude value (float)
	# Return: geotag tuple value
	# e.g.
	#   ( -47.98764, 50.23454, POINT(-47.98764 50.23454) )
	# Exception: thrown if long and/or lat will be none
	#
	def construct_geotag_tuple( self, fLong, fLat ) :
		# define geotag tupple variable
		tupleGeoTag = None
		
		# check if the longitude and latitude values are not None, as well as have valid format
		if fLong == None :
			raise Exception( 'longitude value can not be none' )
		if fLat == None :
			raise Exception( 'latitude value can not be none' )
		
		# format longitute and latitude values to the float number with 12 precision point
		# note: the float will be generated even if the value will be string representation of float number
		fLong = float( "{:0.12g}".format( float( fLong ) ) )
		fLat = float( "{:0.12g}".format( float( fLat ) ) )
		
		# construct OpenGIS point string
		strOpenGISPoint = 'POINT(' + str( fLong ) + ' ' + str( fLat ) + ')'
		
		# construct geotag tupple
		tupleGeoTag = ( fLong, fLat, strOpenGISPoint )
		
		# return geotag tupple
		return tupleGeoTag


	#
	# helper method that will help to determine whether specified social media type is valid (i.e. check it against valid social media types that were 
	# specified in the configuration file)
	#
	# strSocialMediaType - social media type i.e. twitter, instagram etc. OR replay (str)
	# dictConfig - reference to main social media client framework configuration file (dict)
	# 
	# Exception: thrown of specified social media type is none or empty, if social media type is invalid or unsupported
	#
	def validate_social_media_type( self, strSocialMediaType, dictConfig ) :
		# check social media type value
		if not ( isinstance( strSocialMediaType, str ) ):
			raise Exception( 'expected social media type value to be string, but not ' + repr( type( strSocialMediaType ) ) )
		if strSocialMediaType == None or len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be none or empty' )

		# check social media client framework configuration file
		if not ( isinstance( dictConfig, dict ) ) :
			raise Exception( 'expected social media client framework configuration file to be dict, but not ' + repr( type( dictConfig ) ) )
		if len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration file can not be empty' )

		# check if list of valid social media types was specified in the main social media configuration file
		if 'social_media_types' not in dictConfig :
			raise Exception( 'list of supported social media types (social_media_types) was not specified in the main social media client framework configuration file' )
		if len( dictConfig[ 'social_media_types' ] ) == 0 :
			raise Exception( 'list of supported social media types (social_media_types) can not be empty i.e. supported social media types were not specified' )


		# parse supported social media types
		listSupportedSocialMediaTypes = []
		if ',' in dictConfig[ 'social_media_types' ] :
			listSupportedSocialMediaTypes = dictConfig[ 'social_media_types' ].split( ',' )
		else :
			listSupportedSocialMediaTypes.append( dictConfig[ 'social_media_types' ] )

		if strSocialMediaType not in listSupportedSocialMediaTypes :
			raise Exception( 'social media type ' + strSocialMediaType + ' is invalid or unsupported at the moment (supported social media types are ' + repr( listSupportedSocialMediaTypes ) + ')' )


		# return True (mainly needed for unit testing as if social media type will not be valid exception will be thrown)
		return True


	#
	# helper method that will be used to validate social media request bodies
	#
	# strSocialMediaType - social media type i.e. twitter, instagram etc. (str)
	# dictRequestBody - social media request body (dict)
	#
	# Return: refactored (in some cases not) social media request body dict 
	# Exception: thrown if social media type as well as request body were not specified, if any of the social media type request fields will be invalid and/or missing,
	# and if social media type is invalid or unsupported
	#
	def validate_and_refactor_social_media_request_body( self, strSocialMediaType, dictRequestBody, dictConfig ) :
		# validate social media type
		if not ( isinstance( strSocialMediaType, str ) ) :
			raise Exception( 'expecting social media type to be string, but got ' + str( type( strSocialMediaType ) ) )
		if not ( isinstance( dictRequestBody, dict ) ) :
			raise Exception( 'expecting social media request body to be dict, but got ' + str( type( dictRequestBody ) ) )
		if not ( isinstance( dictConfig, dict ) ) :
			raise Exception( 'expecting social media client fgramework configuration file to be dict, but got ' + str( type( dictConfig ) ) )

		# make sure that social media type and request body are not empty
		if len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be empty' )
		if len( dictRequestBody ) == 0 :
			raise Exception( 'social media request body can not be empty' )
		if len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration file can not be empty' )

		# get request type from specified request body
		strRequestType = self.get_request_type( dictRequestBody )

		# start actual request validation process
		# deal with stop_requests
		if strRequestType == 'stop_request' :
			if 'id' in dictRequestBody[ 'stop_request' ] :
				# make sure that handler id is not none or empty
				if dictRequestBody[ 'stop_request' ][ 'id' ] == None or len( dictRequestBody[ 'stop_request' ][ 'id' ] ) == 0 :
					raise Exception( 'handler id to stop can not be none or empty' )

		# deal with any other requests i.e. search_request, stream_request and replay_request
		else :
			if strRequestType == 'search_request' :

				# core checks for all of the social media types
				if 'amqp_exchange' not in dictRequestBody[ 'search_request' ] :
					raise Exception( 'request amqp exchange(i.e. amqp_exchange) was not specified' )
				if dictRequestBody[ 'search_request' ][ 'amqp_exchange' ] == None or len( dictRequestBody[ 'search_request' ][ 'amqp_exchange' ] ) == 0 :
					raise Exception( 'request amqp exchange(i.e. amqp_exchange) can not be empty' )

				if 'amqp_routing' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'request amqp routing(i.e. amqp_routing) was not specified' )
				if dictRequestBody[ 'search_request' ][ 'amqp_routing' ] == None or len( dictRequestBody[ 'search_request' ][ 'amqp_routing' ] ) == 0 :
					raise Exception( 'request amqp routing(i.e. amqp_routing) can not be empty' )

				if 'http_scheme' not in dictRequestBody[ 'search_request' ] :
					raise Exception( 'request http scheme(i.e. http_scheme) was not specified' )
				if dictRequestBody[ 'search_request' ][ 'http_scheme' ] == None or len( dictRequestBody[ 'search_request' ][ 'http_scheme' ] ) == 0 :
					raise Exception( 'request http scheme(i.e. http_scheme) can not be empty' )


				if 'api_target' not in  dictRequestBody[ 'search_request' ] :
					raise Exception( 'request api target(i.e. api_target) was not specified' )
				if dictRequestBody[ 'search_request' ][ 'api_target' ] == None or len( dictRequestBody[ 'search_request' ][ 'api_target' ] ) == 0 :
					raise Exception( 'request api target(i.e. api_target) can not be empty' )


				# NOTE: in many cases api_action can be empty
				#if 'api_action' in dictRequestBody[ 'search_request' ] :
				#	if dictRequestBody[ 'search_request' ][ 'api_action' ] == None or len( dictRequestBody[ 'search_request' ][ 'api_action' ] ) == 0 :
				#		raise Exception( 'request api action(i.e. api_action) can not be empty' )

				if 'api_response_object' not in dictRequestBody[ 'search_request' ] :
					raise Exception( 'request api response object(i.e. api_response_object) was not specified' )
				if dictRequestBody[ 'search_request' ][ 'api_response_object' ] == None :
					raise Exception( 'request api response object(i.e. api_response_object) can not be none, but can be empty' )


				# validate twitter search request
				if strSocialMediaType == 'twitter' :
					# check core twitter search request parameters
					if 'api_key' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'twitter search request oauth api key(i.e. api_key) was not specified' )
					if 'api_key_secret' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'twitter search request oauth api key secret(i.e. api_key_secret) was not specified' )
					if 'api_token' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'twitter search request oauth api token(i.e. api_token) was not specified' )
					if 'api_token_secret' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'twitter search request oauth api token secret(i.e. api_token_secret) was not specified' )
					if 'url_request_params' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'twitter search request url request params(i.e. url_request_params) were not specified' )

					if dictRequestBody[ 'search_request' ][ 'api_key' ] == None or len( dictRequestBody[ 'search_request' ][ 'api_key' ] ) == 0 :
						raise Exception( 'twitter search request oauth api key(i.e. api_key) can not be empty' )
					if dictRequestBody[ 'search_request' ][ 'api_key_secret' ] == None or len( dictRequestBody[ 'search_request' ][ 'api_key_secret' ] ) == 0 :
						raise Exception( 'twitter search request oauth api key secret(i.e. api_key_secret) can not be empty' )
					if dictRequestBody[ 'search_request' ][ 'api_token' ] == None or len( dictRequestBody[ 'search_request' ][ 'api_token' ] ) == 0 :
						raise Exception( 'twitter search request oauth api token(i.e. api_token) can not be empty' )
					if dictRequestBody[ 'search_request' ][ 'api_token_secret' ] == None or len( dictRequestBody[ 'search_request' ][ 'api_token_secret' ] ) == 0 :
						raise Exception( 'twitter search request oauth api token secret(i.e. api_token_secret) can not be empty' )
					if dictRequestBody[ 'search_request' ][ 'url_request_params' ] == None or len( dictRequestBody[ 'search_request' ][ 'url_request_params' ] ) == 0 :
						raise Exception( 'twitter search request url parameters(i.e. url_request_params) can not be empty (please reffer to twitter search request manual)' )

				elif strSocialMediaType == 'youtube' :
					# check core youtube search request parameters
					if 'api_key' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'youtube search request oauth api key(i.e. api_key) was not specified' )
					if 'url_request_params' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'youtube search request url request params(i.e. url_request_params) were not specified' )

					if dictRequestBody[ 'search_request' ][ 'api_key' ] == None or len( dictRequestBody[ 'search_request' ][ 'api_key' ] ) == 0 :
						raise Exception( 'youtube search request oauth api key(i.e. api_key) can not be empty' )
					if dictRequestBody[ 'search_request' ][ 'url_request_params' ] == None or len( dictRequestBody[ 'search_request' ][ 'url_request_params' ] ) == 0 :
						raise Exception( 'youtube search request url request params(i.e. url_request_params) can not be empty (please reffer to youtube search request manual)' )

				elif strSocialMediaType == 'instagram' :
					# check core instagram search request parameters
					if 'access_token' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'instagram search request oauth access token(i.e. access_token) was not specified' )
					if 'url_request_params' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'instagram search request url request params(i.e. url_request_params) were not specified' )

					# check if the values are none or empty as some of the above checks would not be able to detect it (mainly needed for string values)
					if dictRequestBody[ 'search_request' ][ 'access_token' ] == None or len( dictRequestBody[ 'search_request' ][ 'access_token' ] ) == 0 :
						raise Exception( 'instagram search request oauth access token(i.e. access_token) can not be empty' )
					if dictRequestBody[ 'search_request' ][ 'url_request_params' ] == None or len( dictRequestBody[ 'search_request' ][ 'url_request_params' ] ) == 0 :
						raise Exception( 'instagram search request url request params(i.e. url_request_params) can not be empty (please reffer to instagram search request manual)' )


				elif strSocialMediaType == 'foursquare' :
					# check core foursquare search request parameters
					if 'oauth_token' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'foursquare search request oauth token(i.e. oauth_token) was not specified' )
					if 'url_request_params' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'foursquare search request url request params(i.e. url_request_params) were not specified' )

					# check if the values are none or empty as some of the above checks would not be able to detect it (mainly needed for string values)
					if dictRequestBody[ 'search_request' ][ 'oauth_token' ] == None or len( dictRequestBody[ 'search_request' ][ 'oauth_token' ] ) == 0 :
						raise Exception( 'foursquare search request oauth token key(i.e. oauth_token) can not be empty' )
					if dictRequestBody[ 'search_request' ][ 'url_request_params' ] == None or len( dictRequestBody[ 'search_request' ][ 'url_request_params' ] ) == 0 :
						raise Exception( 'foursquare search request url request params(i.e. url_request_params) can not be empty (please reffer to foursquare search request manual)' )

				elif strSocialMediaType == 'facebook' :
					# check core facebook search request parameters
					if 'access_token' not in dictRequestBody[ 'search_request' ] :
						raise Exception( 'facebook search request oauth access token(i.e. access_token) was not specified' )

					# note: commented out as facebook url parameters is an optional element
					#if 'url_request_params' not in dictRequestBody[ 'search_request' ] :
					#	raise Exception( 'facebook search request url request params(i.e. url_request_params) were not specified' )

					# check if the values are none or empty as some of the above checks would not be able to detect it (mainly needed for string values)
					if dictRequestBody[ 'search_request' ][ 'access_token' ] == None or len( dictRequestBody[ 'search_request' ][ 'access_token' ] ) == 0 :
						raise Exception( 'facebook search request oauth access token(i.e. access_token) can not be empty' )

					# note: optionally check
					if 'url_request_params' in dictRequestBody[ 'search_request' ] :
						if dictRequestBody[ 'search_request' ][ 'url_request_params' ] == None or len( dictRequestBody[ 'search_request' ][ 'url_request_params' ] ) == 0 :
							raise Exception( 'facebook search request url request params(i.e. url_request_params) can not be empty (please reffer to instagram search request manual)' )

				else :
					raise Exception( 'search request is not supported by ' + strSocialMediaType + ' at the moment')

			elif strRequestType == 'stream_request' :
				if strSocialMediaType == 'twitter' :
					# check core twitter stream request parameters
					if 'expiry_date' not in dictRequestBody[ 'stream_request' ] :
						raise Exception( 'twitter stream request expiry date(i.e. expiry_date) was not specified' )
					if 'keywords' not in dictRequestBody[ 'stream_request' ] :
						raise Exception( 'twitter stream request keywords(i.e. keywords) were not specified' )
					if 'api_key' not in dictRequestBody[ 'stream_request' ] :
						raise Exception( 'twitter stream request oauth api key(i.e. api_key) was not specified' )
					if 'api_key_secret' not in dictRequestBody[ 'stream_request' ] :
						raise Exception( 'twitter stream request oauth api key secret(i.e. api_key_secret) was not specified' )
					if 'api_token' not in dictRequestBody[ 'stream_request' ] :
						raise Exception( 'twitter stream request oauth api token(i.e. api_token) was not specified' )
					if 'api_token_secret' not in dictRequestBody[ 'stream_request' ] :
						raise Exception( 'twitter stream request oauth api token secret(i.e. api_token_secret) was not specified' )

					# check if the values are none or empty as some of the above checks would not be able to detect it (mainly needed for string values)
					if dictRequestBody[ 'stream_request' ][ 'expiry_date' ] == None or len( dictRequestBody[ 'stream_request' ][ 'expiry_date' ] ) == 0 :
						raise Exception( 'twitter stream request expiry date(i.e. expiry_date) can not be be empty' )
					if dictRequestBody[ 'stream_request' ][ 'keywords' ] == None or len( dictRequestBody[ 'stream_request' ][ 'keywords' ] ) == 0 :
						raise Exception( 'twitter stream request keywords(i.e. keywords) can not be empty (please specify at least one word, e.g. flood)' )
					if dictRequestBody[ 'stream_request' ][ 'api_key' ] == None or len( dictRequestBody[ 'stream_request' ][ 'api_key' ] ) == 0 :
						raise Exception( 'twitter stream request oauth api key(i.e. api_key) can not be empty' )
					if dictRequestBody[ 'stream_request' ][ 'api_key_secret' ] == None or len( dictRequestBody[ 'stream_request' ][ 'api_key_secret' ] ) == 0 :
						raise Exception( 'twitter stream request oauth api key secret(i.e. api_key_secret) can not be empty' )
					if dictRequestBody[ 'stream_request' ][ 'api_token' ] == None or len( dictRequestBody[ 'stream_request' ][ 'api_token' ] ) == 0 :
						raise Exception( 'twitter stream request oauth api token(i.e. api_token) can not be empty' )
					if dictRequestBody[ 'stream_request' ][ 'api_token_secret' ] == None or len( dictRequestBody[ 'stream_request' ][ 'api_token_secret' ] ) == 0 :
						raise Exception( 'twitter stream request oauth api token secret(i.e. api_token_secret) can not be empty' )

					# validate expiry datetime object (it will also automatically check if the stream is less or equal to current time, e.g. already expired)
					try :
						time_helper.parse_iso_datetime( dictRequestBody[ 'stream_request' ][ 'expiry_date' ] )
					except :
						raise Exception( 'invalid expiry date value ' + dictRequestBody[ 'stream_request' ][ 'expiry_date' ] + ' (' + str( sys.exc_info()[1] ) + ')' ) 

				else :
					raise Exception( 'stream request is not supported by ' + strSocialMediaType + ' at the moment')

			elif strRequestType == 'replay_request' :
				if strSocialMediaType == 'replay' :
					# perform core validations
					# social media client framework configuration file
					if 'datasets_dir' not in dictConfig :
						raise Exception( 'datasets directory(i.e. datasets_dir) was not specified in the main social media client framework configuration file' )
					if 'replay_queue_buffer' not in dictConfig :
						raise Exception( 'replay request queue buffer(i.e. replay_queue_buffer) was not specified in the main social media client framework configuration file' )

					# request body
					if 'amqp_exchange' not in dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request amqp exchange(i.e. amqp_exchange) was not specified' )
					if 'amqp_routing' not in dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request amqp routing(i.e. amqp_routing) was not specified' )
					if 'dir_name' not in dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request directory name(i.e. dir_name) was not specified' )
					if 'prefix' not in  dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request file prefix(i.e. prefix) was not specified' )
					if 'start_time' not in dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request start time(i.e. start_time) was not specified' )
					if 'end_time' not in dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request end time(i.e. end_time) was not specified' )
					if 'acceleration_factor' not in dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request acceleration factor(i.e. acceleration_factor) was not specified' )
					if 'media_filter_types' not in dictRequestBody[ 'replay_request' ] :
						raise Exception( 'replay request media filter types(i.e. media_filter_types) were not specified' )
					if dictConfig[ 'datasets_dir' ] == None or len( dictConfig[ 'datasets_dir' ] ) == 0 :
						raise Exception( 'datasets directory(i.e. datasets_dir) can not be empty' )

					# check if the values are none or empty as some of the above checks would not be able to detect it (only needed for string values)
					if dictRequestBody[ 'replay_request' ][ 'amqp_exchange' ] == None or len( dictRequestBody[ 'replay_request' ][ 'amqp_exchange' ] ) == 0 :
						raise Exception( 'replay request amqp exchange(i.e. amqp_exchange) can not be empty' )
					if dictRequestBody[ 'replay_request' ][ 'amqp_routing' ] == None or len( dictRequestBody[ 'replay_request' ][ 'amqp_routing' ] ) == 0 :
						raise Exception( 'replay request amqp routing(i.e. amqp_routing) can not be empty' )
					if dictRequestBody[ 'replay_request' ][ 'dir_name' ] == None or len( dictRequestBody[ 'replay_request' ][ 'dir_name' ] ) == 0 :
						raise Exception( 'replay request directory name(i.e. dir_name) can not be empty' )
					if dictRequestBody[ 'replay_request' ][ 'prefix' ] == None or len( dictRequestBody[ 'replay_request' ][ 'prefix' ] ) == 0 :
						raise Exception( 'replay request file prefix(i.e. prefix) can not be empty' )
					if dictRequestBody[ 'replay_request' ][ 'start_time' ] == None or len( dictRequestBody[ 'replay_request' ][ 'start_time' ] ) == 0 :
						raise Exception( 'replay request start time(i.e. start_time) can not be empty' )
					if dictRequestBody[ 'replay_request' ][ 'end_time' ] == None or len( dictRequestBody[ 'replay_request' ][ 'end_time' ] ) == 0 :
						raise Exception( 'replay request end time(i.e. end_time) can not be empty' )
					if dictRequestBody[ 'replay_request' ][ 'media_filter_types' ] == None or len( dictRequestBody[ 'replay_request' ][ 'media_filter_types' ] ) == 0 :
						raise Exception( 'replay request media filter types(i.e. media_filter_types) can not be empty' )
					if dictConfig[ 'replay_queue_buffer' ] == None or len( dictConfig[ 'replay_queue_buffer' ] ) == 0 :
						raise Exception( 'replay request queue buffer(i.e. replay_queue_buffer) can not be empty' )

					# check if path where replay files will be stored actually exist
					strReplayDirPath = dictConfig[ 'datasets_dir' ] 
					strReplayDirPath = strReplayDirPath.replace('\\\\','\\') + os.path.sep + dictRequestBody[ 'replay_request' ][ 'dir_name' ]
					if not os.path.exists( strReplayDirPath ) :
						raise Exception( 'directory name ' + strReplayDirPath + ' does not exist or could not be found' )

					# make sure that time format specified in start and end date times is correct
					# note: ISO formatted date will need to be used for replay start and end times ()
					# check start date
					datetimeStart = None
					try :
						datetimeStart = time_helper.parse_iso_datetime( dictRequestBody[ 'replay_request' ][ 'start_time' ] ) 
					except :
						raise Exception( 'invalid start datetime value (' + repr( dictRequestBody[ 'replay_request' ][ 'start_time' ] ) + ') (' + str( sys.exc_info()[1] ) + ' )' )

					# check end date
					datetimeEnd = None
					try :
						datetimeEnd = time_helper.parse_iso_datetime( dictRequestBody[ 'replay_request' ][ 'end_time' ] ) 
					except :
						raise Exception( 'invalid end datetime value (' + repr( dictRequestBody[ 'replay_request' ][ 'end_time' ] ) + ') (' + str( sys.exc_info()[1] ) + ' )' )

					# make sure that the end time is less that start time
					if datetimeStart > datetimeEnd :
						raise Exception( 'start time ' + dictRequestBody[ 'replay_request' ][ 'start_time' ] + ' must be less than end time ' + dictRequestBody[ 'replay_request' ][ 'end_time' ] )

					# make sure that acceleration_factor is a valid positive integer or 0
					nAccellerationFactor = 0
					try :
						nAccellerationFactor = int( dictRequestBody[ 'replay_request' ][ 'acceleration_factor' ] )
						if nAccellerationFactor < 0 :
							raise Exception( 'must be positive integer or zero' )
					except :
						raise Exception( 'invalid acceleration factor value [' + dictRequestBody[ 'replay_request' ][ 'acceleration_factor' ] + '] (must be a non negative integer or zero)' )

					# set acceleration factor
					dictRequestBody[ 'replay_request' ][ 'acceleration_factor' ] = nAccellerationFactor

					# check replay queue buffer
					# note: default value of the replay queue buffer is 500
					try :
						# get queue buffer
						strReplayQueueBuffer = dictConfig[ 'replay_queue_buffer' ]

						# make sure that fetched replay queue buffer is not none or empty
						if strReplayQueueBuffer == None or len( strReplayQueueBuffer ) == 0 :
							raise Exception( 'replay queue buffer can not be none or empty' )
						else :
							# convert string buffer value to int
							nTempReplayQueueBufferValue = int( strReplayQueueBuffer )

							if nTempReplayQueueBufferValue < 0 :
								raise Exception( 'replay queue buffer must be positive integer or zero, not ' + str( nTempReplayQueueBufferValue ) )

					except :
						raise Exception( 'failed to read/parse replay queue buffer value (reason: ' + str( sys.exc_info()[1] ) + ')' )

					# check if there are replay files in there are replay files
					listReplayFileTypes = []
					if ',' in dictRequestBody[ 'replay_request' ][ 'media_filter_types' ] :
						listReplayFileTypes = dictRequestBody[ 'replay_request' ][ 'media_filter_types' ].split( ',' )
					else :
						listReplayFileTypes.append( dictRequestBody[ 'replay_request' ][ 'media_filter_types' ] )

					nFilesToReplay = 0
					listFilesToReplay = []
					bFilesExist = False
					for strMediaFilterType in  listReplayFileTypes :
						for strFileName in os.listdir( strReplayDirPath ) :
							self.logger.debug( 'checking if file \'' + strFileName + '\' match prefix \'' + dictRequestBody[ 'replay_request' ][ 'prefix' ] + '\' and social media filter type \'' + strMediaFilterType + \
							'\' (e.g. ' + dictRequestBody[ 'replay_request' ][ 'prefix' ] + '<filename>_' + strMediaFilterType + '.log)' )


							# check if the file exists with specified prefix and current social media filter type
							if strFileName.startswith( dictRequestBody[ 'replay_request' ][ 'prefix' ] ) and ( strFileName.endswith( strMediaFilterType + '.log' ) or strFileName.endswith( strMediaFilterType + '.json' ) or strFileName.endswith( strMediaFilterType ) ) :
									bFilesExist = True
									self.logger.info( 'file ' + strFileName + ' starts with \'' + dictRequestBody[ 'replay_request' ][ 'prefix' ] + '\' and match social media filter type \'' + strMediaFilterType + '\' (file will be replayed)' )

									# increment replay file counter and push file to the temporary list (for debug purposes only)
									nFilesToReplay += 1
									listFilesToReplay.append( strFileName )

							else :
								self.logger.info( 'file ' + strFileName + ' does not start with \'' + dictRequestBody[ 'replay_request' ][ 'prefix' ] + '\' and/or does match social media filter type \'' + strMediaFilterType + '\' (file will not be replayed)' )

					if bFilesExist == False :
						raise Exception( 'no files to replay were found (dir name: \'' + strReplayDirPath + '\', prefix: \'' + dictRequestBody[ 'replay_request' ][ 'prefix' ] + \
							'\', filter types: \'' + repr( dictRequestBody[ 'replay_request' ][ 'media_filter_types' ] ) + '\' (please see a log file for more details )' )

					# log amqp details to the main http endpoint log file
					self.logger.debug( 'amqp details : exchange = ' + str( dictRequestBody[ 'replay_request' ][ 'amqp_exchange' ] ) + ', routing = ' + str( dictRequestBody[ 'replay_request' ][ 'amqp_routing' ] ) )

					# log replay check debug statement
					self.logger.debug( 'found ' + str( nFilesToReplay ) + ' files for replay (i.e. ' + repr( listFilesToReplay ) + ')' )

				else :
					raise Exception( 'replay request is only supported by replay (' + strSocialMediaType + ' was specified')

			else :
				raise Exception( 'specified unknown or unsupported social media request ' + strRequestType + ' (supported social media requests are search_request, stream_request and replay_request' )


		self.logger.debug( strSocialMediaType + ' request body validation is complete' )
		self.logger.debug( 'request body being validated: ' + repr( dictRequestBody ) )
		self.logger.debug( 'social media configuration specified during request body validation: ' + repr( dictConfig ) )


		# return refactored request body
		return dictRequestBody	



	#
	# helper method that will get social media (or replay) request type i.e. search, stream or replay
	#
	# dictRequestBody - request body json (dict)
	#
	# Return: strRequestType - social media (or replay) request type i.e. search, stream or replay (str)
	# Exception: thrown if dictRequestBody is not or empty, if search_request|stream_request|replay_request|stop_request is not found in the request body
	#
	def get_request_type( self, dictRequestBody ) :
		strRequestType = ''

		if not( isinstance( dictRequestBody, dict ) ) :
			raise Exception( 'expecting request body to be json, but got ' + str( type( dictRequestBody ) ) )

		# validate request body 
		if len( dictRequestBody ) == 0 :
			raise Exception( 'request body can not be none or empty' )

		# check request type
		if 'search_request' in dictRequestBody :
			strRequestType = 'search_request'

		elif 'stream_request' in dictRequestBody :
			strRequestType = 'stream_request'

		elif 'replay_request' in dictRequestBody :
			strRequestType = 'replay_request'

		elif 'stop_request' in dictRequestBody :
			strRequestType = 'stop_request'

		else : # unknown request
			raise Exception( 'could not find supported request type in specified request body (supported request types are search_request, stream_request, replay_request and stop_request), request body specified ' + repr( dictRequestBody ) )

		# return request type
		return strRequestType


	#
	# helper method that will help to determine whether there is a next page available in social media search result (i.e. next available search page)
	#
	# strSocialMediaType - social media type i.e. twitter, youtube etc. (need to be known in order to determine how to gather next page result json key) (str)
	# listResults - json of content items that were revealed diring social media search (NOTE: it will be a raw result that will contain necessary metadata about search outcome) (dict)
	# dictConfig - main social media client configuration file (needed for social media type validation purpose) 
	#
	# Return: strNextPageValue value of next page (default empty) depending on social media type
	# Exception: thrown of social media type is None, empty of unknown, if dictConfig is None or empty
	#
	def get_next_page_value( self, strSocialMediaType, jsonResults, dictConfig ) :
		# default value
		strNextPageValue = ''

		# validate social media type
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ):
			raise Exception( 'expected social media type to be a string/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be empty' )

		# validate social media client framework configuration file
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected social media client framework to be a dict, but got ' + str( type( dictConfig ) ) )
		if isinstance( dictConfig, dict) and len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration can not be empty' )

		# check if social media type is supported
		self.validate_social_media_type( strSocialMediaType, dictConfig )

		# we need to be less strict on actual results as somethimes (rare) an empty list is returned (no meta data etc.)
		if not isinstance( jsonResults, dict ) :
			self.logger.warn( 'expected social media results list to be dict, but got ' + str( type( jsonResults ) ) )
		if isinstance( jsonResults, dict ) and len( jsonResults ) == 0 :
			self.logger.warn( 'list of ' + strSocialMediaType + ' results is empty (no paging information will be returned)' )

		# get twitter page token
		if strSocialMediaType == 'twitter' :
			if isinstance( jsonResults, dict ) and 'search_metadata' in jsonResults and 'next_results' in jsonResults[ 'search_metadata' ]:
				if jsonResults[ 'search_metadata' ][ 'next_results' ] == None or len( jsonResults[ 'search_metadata' ][ 'next_results' ] ) == 0 : 
					self.logger.warn( 'next results was specified for ' + strSocialMediaType + ', but its value was none or empty for some reason (no paging information will be returned)' )

				else :
					# first of all get next_results value
					strNextResults = jsonResults[ 'search_metadata' ][ 'next_results' ]

					# start parsing the value
					# remove first ? character
					strNextResults = strNextResults[1:]

					# split next results string on '='
					listNextResultsTempSplit = strNextResults.split("&")

					# loop over the split results and populate new requests
					for strResutParam in listNextResultsTempSplit :
						# first of all split the result on '='
						listResultParamSplit = strResutParam.split("=")

						strRequestKey = listResultParamSplit[0]
						strRequestValue = listResultParamSplit[1]

						if strRequestKey == "max_id" :
							strNextPageValue = strRequestValue

							# break the loop as any futher processing is not required
							break

			# note: in some cases next results are not returned (seems to appear randomly in some cases) therefore we will try to get 
			# just max_id from the metadata
			#elif isinstance( jsonResults, dict ) and 'search_metadata' in jsonResults and 'max_id' in jsonResults[ 'search_metadata' ]: 
			#	self.logger.debug( 'next_results were not found in the search response metadata (search response metadata ' + str( repr( jsonResults[ 'search_metadata' ] ) ) + ')' )
			#	self.logger.debug( 'trying to get plain max_id value from the search metadata...' )

			#	if len( str( jsonResults[ 'search_metadata' ][ 'max_id' ] ) ) > 0 :
			#		strNextPageValue = str( jsonResults[ 'search_metadata' ][ 'max_id' ] )

			#		# log extra debug statement
			#		self.logger.debug( 'found plain max_id value (' + str( strNextPageValue ) + ') that will be used to get next page ' )

			#	# log debug statement in case 
			#	else :
			#		self.logger.info( 'max_id value was empty i.e. ' + repr( json.dumps( jsonResults[ 'search_metadata' ] ) ) )


		# get youtube page token
		elif strSocialMediaType == 'youtube' :
			if isinstance( jsonResults, dict ) and 'nextPageToken' in jsonResults :
				if jsonResults[ 'nextPageToken' ] == None or len( jsonResults[ 'nextPageToken' ] ) == 0 : 
					self.logger.warn( 'next page was specified for ' + strSocialMediaType + ', but its value was none or empty for some reason (no paging information will be returned)' )

				else :
					strNextPageValue = jsonResults[ 'nextPageToken' ]


		# get foursquare page token (not used at the moment)
		elif strSocialMediaType == 'foursquare' :
			pass

		# get instagram page token
		elif strSocialMediaType == 'instagram' :
			if isinstance( jsonResults, dict ) and 'pagination' in jsonResults and 'next_max_id' in jsonResults[ 'pagination' ] :
				if jsonResults[ 'pagination' ][ 'next_max_id' ] == None or len( jsonResults[ 'pagination' ][ 'next_max_id' ] ) == 0 : 
					self.logger.warn( 'next page was specified for ' + strSocialMediaType + ', but its value was none or empty for some reason (no paging information will be returned)' )

				else :
					strNextPageValue = jsonResults[ 'pagination' ][ 'next_max_id' ]


		# get facebook page token
		elif strSocialMediaType == 'facebook' :
			if isinstance( jsonResults, dict ) and 'paging' in jsonResults and 'next' in jsonResults[ 'paging' ]:
				if jsonResults[ 'paging' ][ 'next' ] == None or len( jsonResults[ 'paging' ][ 'next' ] ) == 0 : 
					self.logger.warn( 'next results was specified for ' + strSocialMediaType + ', but its value was none or empty for some reason (no paging information will be returned)' )

				else :
					# first of all get next_results value
					strNextResults = jsonResults[ 'paging' ][ 'next' ]

					# split url on ?
					if '?' in strNextResults:
						if '__paging_token' in strNextResults :
							# if URL parameters were found and __paging_token present then start extracting next page token value
							listNextResultsTempSplit = strNextResults.split( '?' )
							strURLParameters = listNextResultsTempSplit[1]

							# split all URL parameters on '&'
							listURLParameters = strURLParameters.split( '&' )

							# loop over URL parameters list and try to extract next page token value
							for strResutParam in listURLParameters :
								# first of all split the result on '='
								listResultParamSplit = strResutParam.split( '=' )

								strRequestKey = listResultParamSplit[0]
								strRequestValue = listResultParamSplit[1]

								if strRequestKey == "__paging_token" :
									strNextPageValue = strRequestValue

									# break the loop as any futher processing is not required
									break

						else :
							self.logger.warn( 'could not find next page token (i.e. __paging_token) in URL ' + strNextResults )
					else :
						self.logger.warn( 'could not find URL parameters (failed URL: ' + strNextResults + ')' )


		if len( strNextPageValue ) > 0 :
			self.logger.debug( 'found next page token for ' + strSocialMediaType + ' (next page value ' + strNextPageValue + ')' )

		else :
			self.logger.debug( 'next page was not found in ' + strSocialMediaType + ' results' )

		# return result
		return strNextPageValue


	#
	# validate common social media search poll parameters (applicable to most social media searched) 
	#
	# dictRequestBody - social media request body that should contain poll_search_params
	#
	# Return: dictRequestBody refactored (if necessary) poll search request
	# Exception: if dictRequestBody is None or empty, if core poll request parameters are invalid, if dictConfig (main social media client framework config file) is None or empty
	#
	def validate_and_refactor_social_media_serch_poll_parameters( self, dictRequestBody, dictConfig ) :
		# perform initial checks on request body
		if not isinstance( dictRequestBody, dict ) :
			raise Exception( 'expected social media request body to be a dict, but got ' + str( type( dictRequestBody ) ) )
		if len( dictRequestBody ) == 0 :
			raise Exception( 'social media request body can not be empty' )

		# validate main social media client framework configuration
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected social media configuration be a dict, but got ' + str( type( dictConfig ) ) )
		if len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration file can not be empty' )

		# double check if main social media client framework configutation contains default poll search parameters (if not them its quite ambiguous to preceed any futher with poll request)
		if 'n_default_poll_interval' not in dictConfig :
			raise Exception( 'default poll interval (i.e. n_default_poll_interval) was not specified in the main social media configuration file' )
		if 'n_default_poll_interval_page_count' not in dictConfig :
			raise Exception( 'default poll interval page count (i.e. n_default_poll_interval_page_count) was not specified in the main social media configuration file' )


		# check if poll_search_params were actually specified
		if 'poll_search_params' not in dictRequestBody :
			raise Exception( 'poll_search_params were not specified' )

		# start actual validation of poll search parameters
		# first of all check core poll parameters
		if 'poll_start_time' not in dictRequestBody[ 'poll_search_params' ] :
			raise Exception( 'requested to do a continuous poll search but did not specify poll start time parameter i.e. poll_start_time' )
		if 'poll_end_time' not in dictRequestBody[ 'poll_search_params' ] :
			raise Exception( 'requested to do a continuous poll search but did not specify poll end time parameter i.e. poll_end_time' )

		if dictRequestBody[ 'poll_search_params' ][ 'poll_start_time' ] == None or len( str( dictRequestBody[ 'poll_search_params' ][ 'poll_start_time' ] ) ) == 0 :
			raise Exception( 'poll start time (i.e. poll_start_time) can not be empty' )
		if dictRequestBody[ 'poll_search_params' ][ 'poll_end_time' ] == None or len( str( dictRequestBody[ 'poll_search_params' ][ 'poll_end_time' ] ) ) == 0 :
			raise Exception( 'poll end time (i.e. poll_end_time) can not be empty' )

		# validate poll_start time
		try :
			time_helper.parse_iso_datetime( dictRequestBody[ 'poll_search_params' ][ 'poll_start_time' ] )

		except Exception, e :
			raise Exception( 'invalid poll_start_time date time was specified ' + str( dictRequestBody[ 'poll_search_params' ][ 'poll_start_time' ] ) + ' (reason: ' + str( e ) + ')' )

		# validate poll_end time
		try :
			time_helper.parse_iso_datetime( dictRequestBody[ 'poll_search_params' ][ 'poll_end_time' ] )

		except Exception, e :
			raise Exception( 'invalid poll_end_time date time was specified ' + str( dictRequestBody[ 'poll_search_params' ][ 'poll_end_time' ] ) + ' (reason: ' + str( e ) + ')' )


		# create datetime objects for poll start and end times
		dateTimePollStart = time_helper.parse_iso_datetime( dictRequestBody[ 'poll_search_params' ][ 'poll_start_time' ] )
		dateTimePollEnd = time_helper.parse_iso_datetime( dictRequestBody[ 'poll_search_params' ][ 'poll_end_time' ] )


		# make sure that end time is not less than start time
		if dateTimePollEnd < dateTimePollStart :
			raise Exception( 'poll search end datetime ' + time_helper.format_iso_datetime( dateTimePollEnd ) + ' can not be less than poll search end time ' + time_helper.format_iso_datetime( dateTimePollStart ) )


		# check optional parameters
		if 'poll_interval_page_count' not in dictRequestBody[ 'poll_search_params' ] :
			self.logger.warn( 'page cound per poll interval was not specified, using default value of -1 (all available pages will be searched)' )

			# set default value of interval_page_count
			dictRequestBody[ 'poll_search_params' ][ 'poll_interval_page_count' ] = -1

		# validate poll_interval_page_count
		else :
			try :
				nPollIntervalPageCount = int( dictRequestBody[ 'poll_search_params' ][ 'poll_interval_page_count' ] )

				# store integer value
				dictRequestBody[ 'poll_search_params' ][ 'poll_interval_page_count' ] = nPollIntervalPageCount

			except Exception, e :
				raise Exception( 'invalid poll interval page count ' + str( dictRequestBody[ 'poll_search_params' ][ 'poll_interval_page_count' ] ) + ', expected to be an integer' )

				# TODO VK FIX THIS INDENT ERROR PROPERLY
				raise Exception( 'invalid poll_interval_page_count was specified ' )

		# validate and refactor poll interval
		if 'poll_interval' not in dictRequestBody[ 'poll_search_params' ] :
			raise Exception( 'poll interval (i.e. poll_interval) was not specified (example poll interval is 15s, 5m, 2h, 1d etc.)' )

		# call selarate method that will validate and parse poll_interval value
		listPollSearchInterval = self.validate_and_parse_poll_search_interval( dictRequestBody[ 'poll_search_params' ][ 'poll_interval' ] )

		# parse the results and store them back in dictionary
		dictRequestBody[ 'poll_search_params' ][ 'poll_interval_value' ] = listPollSearchInterval[ 0 ]
		dictRequestBody[ 'poll_search_params' ][ 'poll_interval_type' ] = listPollSearchInterval[ 1 ]

		# return refactored request body (i.e. refactored poll_search_params)
		return dictRequestBody


	#
	# helper method that will validate default poll search interval
	#
	# i.e. 
	#
	# search interval value must be specified using the following pattern 30s, 5m, 1d where 
	# 30s - is equivalent to 30 seconds
	# 5m - is equivalent to 5 minutes
	# 2h - is equivalent to 2 hours
	# 1d - is equivalent to 1 day
	#
	# strDefaultPollSearchInterval - default poll search interval value (str)
	# 
	# Return: listDefaultPollSearchInterval parsed poll search interval value in the following format
	#
	# [ nNumbericValue, strTimeType ] i.e. [ 30, seconds ]
	#
	# Exception: if strDefaultPollSearchInterval is None or empty, if default poll search interval was specified using wrong format
	#
	def validate_and_parse_poll_search_interval( self, strPollSearchInterval ) :
		# define return value
		nTimeToAdd = 0 # i.e. 30 
		strTimeType = '' # i.e. seconds
		listPollSearchInterval = []

		# validate parsed value
		if not isinstance( strPollSearchInterval, str ) and not isinstance( strPollSearchInterval, unicode ):
			raise Exception( 'expected poll search interval (i.e. poll_interval) to be a string/unicode, but got ' + str( type( strPollSearchInterval ) ) )
		if len( strPollSearchInterval ) == 0 :
			raise Exception( 'poll search interval (i.e. poll_interval) value can not be empty' )

		# get time value that will need to be added
		strTimeToAdd = strPollSearchInterval[:-1]
		try :
			# try to convert if to integer is string validating for a digit was successful
			nTimeToAdd = int( strTimeToAdd )

		except :
			raise Exception( 'failed to get numeric time value poll interval value from ' + strTimeToAdd + ' (e.g. please specify poll interal as 30s, 5m, 1d or similar)' )

		# make sure that it ends with letter s(seconds), m(minutes), h(hours) or d(days)
		strLastChar = strPollSearchInterval[-1:]
		if strLastChar == 's' :
			strTimeType = 'seconds'
		elif strLastChar == 'm' :
			strTimeType = 'minutes'
		elif strLastChar == 'h' :
			strTimeType = 'hours'
		elif strLastChar == 'd' :
			strTimeType = 'days'
		else :
			raise Exception( 'social media configuration default poll interval value (i.e. n_default_poll_interval) must end with s(seconds), m(minutes), h(hours) or d(days), but not ' + str( strLastChar ) + ' (specified value ' + strPollSearchInterval + ')' )

		# store results into the list
		# [0] - time to add
		# [1] - type of time to add
		listPollSearchInterval.append( nTimeToAdd )
		listPollSearchInterval.append( strTimeType )

		# return results list
		return listPollSearchInterval


	#
	# increment datatime by seconds, minutes, hours or days
	#
	# strDateTime - datetime that will need to be incremented (str)
	# nTimeToAdd - value to add to datetime object (int)
	# strTimeType - type type to add i.e. seconds, minutes, hours, weeks or days (str)
	#
	# Return: incremented datetime (str)
	# Exception: 
	#
	def increment_datetime( self, strDateTime, nTimeToAdd, strTimeType ) :
		# store returned value
		strTimeIncremented = ''

		# perform core checks
		if not isinstance( strDateTime, str ) and not isinstance( strDateTime, unicode ) :
			raise Exception( 'expected increment datetime to be a string/unicode, but got ' + str( type( strDateTime ) ) )
		if not isinstance( nTimeToAdd, int ) :
			raise Exception( 'expected increment datetime value to be an int, but got ' + str( type( nTimeToAdd ) ) )
		if not isinstance( strTimeType, str ) and not isinstance( strTimeType, unicode ) :
			raise Exception( 'expected increment datetime time type to be a string/unicode, but got ' + str( type( strTimeType ) ) )

		if len( strDateTime ) == 0 :
			raise Exception( 'increment datetime can not be empty' )
		if len( str( nTimeToAdd ) ) == 0 :
			raise Exception( 'increment datetime value can not be empty' )
		if len( strTimeType ) == 0 :
			raise Exception( 'increment datetime time type can not be empty' )


		# prepare datetime object from passed string
		dateTime = time_helper.parse_iso_datetime( strDateTime )

		dateTimeIncremented = None
		if strTimeType == 'seconds' :
			dateTimeIncremented = dateTime + datetime.timedelta( seconds = nTimeToAdd )
		elif strTimeType == 'minutes' :
			dateTimeIncremented = dateTime + datetime.timedelta( minutes = nTimeToAdd )
		elif strTimeType == 'days' :
			dateTimeIncremented = dateTime + datetime.timedelta( days = nTimeToAdd )
		elif strTimeType == 'hours' :
			dateTimeIncremented = dateTime + datetime.timedelta( hours = nTimeToAdd )
		elif strTimeType == 'weeks' :
			dateTimeIncremented = dateTime + datetime.timedelta( weeks = nTimeToAdd )
		else :
			raise Exception( 'unknown or unsupported type of time ' + repr( strTimeType ) )

		# convert datetime back to string
		strTimeIncremented = time_helper.format_iso_datetime( dateTimeIncremented )

		# return incremented datetime object (str)
		return strTimeIncremented


	#
	# convert minutes, hours and days to seconds
	#
	# nTimeValue - numeric value that will be used to convert to seconds i.e. 30 (int)
	# strTimeType - time type i.e. minutes (str)
	#
	# Return: nSeconds time value in seconds
	# Exception: thrown if core parameter validation checks will fail
	#
	def convert_to_seconds( self, nTimeValue, strTimeType ) :
		# store return value
		nSeconds = 0

		# perform core checks
		# check time value (nTimeValue)
		if not isinstance( nTimeValue, int ) :
			raise Exception( 'expected time value to be an integer, but got ' + str( type( nTimeValue ) ) )
		if nTimeValue <= 0 :
			raise Exception( 'time value must be a positive integer, but not ' + str( nTimeValue ) )

		# check time value (strTimeType)
		if not isinstance( strTimeType, str ) and not isinstance( strTimeType, unicode ):
			raise Exception( 'expected time type value to be a string/unicode, but got ' + str( type( strTimeType ) ) )
		if len( strTimeType ) == 0 :
			raise Exception( 'time type value can not be empty' )

		listAllowedTimeTypes = []
		listAllowedTimeTypes.append( 'minutes' )
		listAllowedTimeTypes.append( 'hours' )
		listAllowedTimeTypes.append( 'days' )

		# finally process a time value
		if strTimeType == 'seconds' :
			self.logger.debug( 'returning value ' + str( nTimeValue ) + ' seconds since its value is already in seconds' )

			nSeconds = nTimeValue

		# process 
		else :
			if strTimeType not in listAllowedTimeTypes :
				raise Exception( 'invalid or unsupported time type ' + strTimeType + ' (supported time types are: ' + repr( listAllowedTimeTypes ) + ')' )

			self.logger.debug( 'converting time value ' + str( nTimeValue ) + ' from ' + strTimeType + ' to seconds' )

			if strTimeType == 'minutes' :
				nSeconds = nTimeValue * 60
			if strTimeType == 'hours' :
				nSeconds = nTimeValue * 60 * 60
			if strTimeType == 'days' :
				nSeconds = nTimeValue * 60 * 60 * 24

			self.logger.debug( 'converted value: ' + str( nSeconds ) + ' seconds' )

		# return value in seconds
		return nSeconds


	#
	# helper method that will convert ISO 8601 formatted timestamp to specific social media format timestamp
	#
	# socialMediaType - social media type i.e. twitter, youtube etc. (str)
	# strTimestamp - ISO 8601 formatter timestamp (str)
	#
	# Return: strFormattedTimestamp - formatted timestamp specific to social media
	# Exception: thrown if any of the specified function parameters will be invalid or missing
	#
	def generate_specific_social_media_timestamp( self, socialMediaType, strTimestamp ) :
		# store returned value
		strFormattedTimestamp = ''

		if not isinstance( socialMediaType, str ) and not isinstance( socialMediaType, unicode ) :
			raise Exception( 'expected social media type to be a string/unicode, but got ' + str( type( socialMediaType ) ) )
		if not isinstance( strTimestamp, str ) and not isinstance( strTimestamp, unicode ) :
			raise Exception( 'expected ISO 8601 timestamp to be a string/unicode, but got ' + str( type( strTimestamp ) ) )
		if len( socialMediaType ) == 0 :
			raise Exception( 'social media type can not be empty' )
		if len( strTimestamp ) == 0 :
			raise Exception( 'ISO 8601 timestamp value can not be empty' )

		# make sure that timestamp is actuall ISO 8601 formatted
		# note: current method would raise an exception if timestamp will not be valid
		dateTimeToFormat = time_helper.parse_iso_datetime( strTimestamp )

		# process and format timestamp
		# 2006-03-08T23:00:41.000Z
		# 2015-12-14T14:37:00+00:00
		if socialMediaType == 'youtube' :
			# first of all remove +00:00 from the end of the timestamp
			# strTimestamp = strTimestamp.split( '+' )[ 0 ]

			# add .000Z to timestamp
			strFormattedTimestamp = dateTimeToFormat.strftime( '%Y-%m-%dT%H:%M:%S' ) + "Z"

		# ISO8601 to unix timestamp
		elif socialMediaType == 'instagram' :
			strFormattedTimestamp = str( time.mktime( dateTimeToFormat.timetuple() ) + 1e-6 * dateTimeToFormat.microsecond )

		else :
			raise Exception( 'other social media types are not implemented yet' )

		# return formatted timestamp
		return strFormattedTimestamp


	
	#
	# helper method that will allow to get default sleep time for specified social media type
	#
	# strSocialMediaType - social media type value i.e. youtube, twitter etc. (str)
	# dictConfig - main social media configuration file (dict)
	#
	# Return: nDefaultSleepTime default social media sleep time (int)
	# Exception: thrown if function parameter validation will fail
	#
	def get_default_sleep_time_between_requests( self, strSocialMediaType, dictConfig ) :
		# store returned sleep time value in seconds (int)
		nDefaultSleepTime = 0

		# perform core validation checks
		# validate social media type
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ):
			raise Exception( 'expected social media type to be a string/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be empty' )

		# validate social media dict
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected social media client framework to be a dict, but got ' + str( type( dictConfig ) ) )
		if len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration file can not be empty' )


		# make sure that we are dealing with supported social media type
		self.validate_social_media_type( strSocialMediaType, dictConfig )

		# start actual processing
		# process youtube sleep time
		if strSocialMediaType == 'youtube' :
			if 'youtube_sleep_time_between_requests' not in dictConfig :
				raise Exception( 'default youtube sleep time (i.e. youtube_sleep_time_between_requests) parameter was not specified' )
			if dictConfig[ 'youtube_sleep_time_between_requests' ] == None or len( dictConfig[ 'youtube_sleep_time_between_requests' ] ) == 0 :
				raise Exception( 'default youtube sleep time (i.e. youtube_sleep_time_between_requests) can not be None or empty' )

			nDefaultSleepTime = int( dictConfig[ 'youtube_sleep_time_between_requests' ] )

		# process twitter sleep time
		elif strSocialMediaType == 'twitter' :
			if 'twitter_sleep_time_between_requests' not in dictConfig :
				raise Exception( 'default twitter sleep time (i.e. twitter_sleep_time_between_requests) parameter was not specified' )
			if dictConfig[ 'twitter_sleep_time_between_requests' ] == None or len( dictConfig[ 'twitter_sleep_time_between_requests' ] ) == 0 :
				raise Exception( 'default twitter sleep time (i.e. twitter_sleep_time_between_requests) can not be None or empty' )

			nDefaultSleepTime = int( dictConfig[ 'twitter_sleep_time_between_requests' ] )

		# process instagram sleep time
		elif strSocialMediaType == 'instagram' :
			if 'instagram_sleep_time_between_requests' not in dictConfig :
				raise Exception( 'default instagram sleep time (i.e. instagram_sleep_time_between_requests) parameter was not specified' )
			if dictConfig[ 'instagram_sleep_time_between_requests' ] == None or len( dictConfig[ 'instagram_sleep_time_between_requests' ] ) == 0 :
				raise Exception( 'default instagram sleep time (i.e. instagram_sleep_time_between_requests) can not be None or empty' )

			nDefaultSleepTime = int( dictConfig[ 'instagram_sleep_time_between_requests' ] )

		# process foursquare sleep time
		elif strSocialMediaType == 'foursquare' :
			if 'foursquare_sleep_time_between_requests' not in dictConfig :
				raise Exception( 'default foursquare sleep time (i.e. foursquare_sleep_time_between_requests) parameter was not specified' )
			if dictConfig[ 'foursquare_sleep_time_between_requests' ] == None or len( dictConfig[ 'foursquare_sleep_time_between_requests' ] ) == 0 :
				raise Exception( 'default foursquare sleep time (i.e. foursquare_sleep_time_between_requests) can not be None or empty' )

			nDefaultSleepTime = int( dictConfig[ 'foursquare_sleep_time_between_requests' ] )

		# process facebook sleep time
		elif strSocialMediaType == 'facebook' :
			if 'facebook_sleep_time_between_requests' not in dictConfig :
				raise Exception( 'default facebook sleep time (i.e. facebook_sleep_time_between_requests) parameter was not specified' )
			if dictConfig[ 'facebook_sleep_time_between_requests' ] == None or len( dictConfig[ 'facebook_sleep_time_between_requests' ] ) == 0 :
				raise Exception( 'default facebook sleep time (i.e. facebook_sleep_time_between_requests) can not be None or empty' )

			nDefaultSleepTime = int( dictConfig[ 'facebook_sleep_time_between_requests' ] )

		# process foursquare sleep time
		else :
			raise Exception( 'not implemented' )

		# return sleep time
		return nDefaultSleepTime


	#
	# calculate speep time based on start and end times (will be mainly used during social media poll search requests)
	#
	# datetimeStart - start time (datetime)
	# datetimeEnd - end time (datetime)
	#
	# Return: nSleepTimeSeconds number of seconds to sleep (int)
	# Exception: if fails to validate start and end times, if datetime objects will not be ISO8601 formatted
	#
	def calculate_time_difference( self, datetimeStart, datetimeEnd ) :
		# store retuen value 
		nSleepTimeSeconds = 0

		# perform validation
		if not isinstance( datetimeStart, datetime.datetime ) :
			raise Exception( 'expected start datetime object to be a datetime, but got ' + str( type( datetimeStart ) ) )
		if not isinstance( datetimeEnd, datetime.datetime ) :
			raise Exception( 'expected end datetime object to be a datetime, but got ' + str( type( datetimeEnd ) ) )

		# make sure that datetimes are ISO8601 formatted in order to avoid any ambiguities
		strDatetimeStart = time_helper.format_iso_datetime( datetimeStart )
		strDatetimeEnd = time_helper.format_iso_datetime( datetimeEnd )

		# make sure that end time if not less that start time
		if datetimeEnd < datetimeStart :
			raise Exception( 'end time ' + strDatetimeEnd + ' can not be less that start time ' + strDatetimeStart )

		# calcualte actual time difference
		datetimeDelta = datetimeEnd - datetimeStart

		# calculate total seconds (i.e. convert whatever time amount to seconds)
		nSleepTimeSeconds = datetimeDelta.total_seconds()

		# return difference in seconds
		return nSleepTimeSeconds


	#
	# common helper method for social media search threads that will help to calculate sleep time between requests
	#
	# calculations will be based on several factors:
	# - start of poll search and end time of poll search request (note: it is not related to paging requests where sleep time will be default
	#   per social media)-> total time of poll search request
	# - requested poll interval value and type i.e. poll request every 10 minutes etc.
	#
	# 
	# - datetimePollStartSearch - poll searsh start time (datetime)
	# - datetimePollEndSearch - poll search end time (datetime)
	# - nPollIntervalValue - poll interval value i.e. 5
	# - strPollIntervalType - poll interval time type value i.e. minutes
	# - nDefaultSleepTimeBetweenRequests - default time (seconds) that it is necessary to sleep between search requests in order not to reach throttle limit (int)
	#	note: default value will be returned if total poll search request is larger or equal to specified poll interval value
	#	i.e. if poll interval value was specified to be 5m (e.g. 300 seconds) and actual poll search request took about 400 seconds to complete (e.g. return all pages etc.)
	# 	then in this case it will be necessary to sleep only minimal (e.g. default) amount of time and continue straight away
	
	#
	# Return: nSleepTimeBetweenPollRequests calculated sleep time between requests (calculated based on specified function parameters i.e. current poll search start/end times + 
	# specified poll interval value)
	# Exception: thrown of function parameter validation fails, if poll end time is less than poll start time, if invalid poll search value and/or type was specified
	#
	def calculate_sleep_time_between_poll_requests( self, datetimePollStartSearch, datetimePollEndSearch, nPollIntervalValue, strPollIntervalType, nDefaultSleepTimeBetweenRequests ) :
		# store return sleep time value (seconds)
		nSleepTimeBetweenPollRequests = 0

		# validate function parameters
		if not isinstance( datetimePollStartSearch, datetime.datetime ) :
			raise Exception( 'expected poll search start time to be datetime, but got ' + str( type( datetimePollStartSearch ) ) )
		if not isinstance( datetimePollEndSearch, datetime.datetime ) :
			raise Exception( 'expected poll search end time to be datetime, but got ' + str( type( datetimePollEndSearch ) ) )
		if not isinstance( nPollIntervalValue, int ) :
			raise Exception( 'expected poll interval value to be integer, but got ' + str( type( nPollIntervalValue ) ) )
		if not isinstance( strPollIntervalType, str ) and not isinstance( strPollIntervalType, unicode ) :
			raise Exception( 'expected poll interval time type to be string/unicode, but got ' + str( type( strPollIntervalType ) ) )

		# calculate time that it took to execute poll request
		# note: exception will be raised if poll search start and end times (any of them) will not be ISO8601
		nTotalPollSearchTime = self.calculate_time_difference( datetimePollStartSearch, datetimePollEndSearch )

		self.logger.debug( 'difference between poll start ' + time_helper.format_iso_datetime( datetimePollStartSearch ) + ' and end ' + time_helper.format_iso_datetime( datetimePollEndSearch ) + ' times is ' + str( nTotalPollSearchTime )  + ' seconds' )

		# calculate amount of time that is needed between poll search requests (specified in the request under "poll_interval")
		#
		# i.e. convert 5 minutes to 300 seconds
		#
		nSpecifiedPollSearchInterval = self.convert_to_seconds( nPollIntervalValue, strPollIntervalType )

		self.logger.debug( 'calculating sleep time between poll search requests...' )

		# as a final step it is necessary to determine whether specified poll search interval was less than actual time it took to calculate the request
		# if specified poll search time was less than actual poll search time
		#
		# i.e. specified poll search time was 5 days, but actual poll search took 9 days -> then sleep for default amount of time (specific 
		# to social media) and start next poll search (if any) straight after
		# 
		if nSpecifiedPollSearchInterval <= nTotalPollSearchTime :
			nSleepTimeBetweenPollRequests = nDefaultSleepTimeBetweenRequests

			self.logger.debug( 'poll search took more time (' + str( nTotalPollSearchTime ) + ' seconds) than specified interval between poll searches (i.e. ' + str(nSpecifiedPollSearchInterval  ) + ' seconds)' )
			self.logger.debug( 'will be sleeping for default amount of time between requests (i.e. ' + str( nDefaultSleepTimeBetweenRequests ) + ' seconds)' )

		# specified poll search time was larger than actual poll search interval
		#
		# i.e. specified poll search interval was 3 days, but actual poll search finished in 1 day -> need to calculate time difference that social media thread
		# will use to sleep (seconds) between next poll search request
		#
		else :
			nSleepTimeBetweenPollRequests = nSpecifiedPollSearchInterval - nTotalPollSearchTime

			self.logger.debug( 'poll search took less time (' + str( nTotalPollSearchTime ) + ' seconds) than specified interval between poll searches is ' + str(nSpecifiedPollSearchInterval  ) + ' seconds' )
			self.logger.debug( 'calculating remaining sleep time before next poll search...' )

			# make sure that sleep time is at least equal to default sleep time
			# note: it is necessary to avoid any throttle issues
			if nSleepTimeBetweenPollRequests < nDefaultSleepTimeBetweenRequests :
				nSleepTimeBetweenPollRequests = nDefaultSleepTimeBetweenRequests

				# log debug statement
				self.logger.debug( 'note: calculated sleep time ' + str( nSleepTimeBetweenPollRequests ) + ' seconds is less than default sleep time ' + str( nDefaultSleepTimeBetweenRequests ) + ' seconds (default sleep time of ' + str( nDefaultSleepTimeBetweenRequests ) + ' will be used in order to avoid throttle limit issues)' )


		# return sleep time between requests
		return nSleepTimeBetweenPollRequests


	#
	# helper method for social media trhead poll requests that will help to check whether poll end time has been reached
	#
	# i.e.
	#
	# list of social media item will be passed to the function, each social media item will be parsed and depending on social media type
	# its timestamp will be fetched
	#
	# each timestamp will be checked against specified poll search end
	#
	# if poll search end time was reached then boolean flag will be returned from the function (without any futher checks)
	#
	# strSocialMediaType - social media type e.g. twitter, youtube etc. (str)
	# listJSONItems - list of social media query result content items (list)
	# datetimePollEndTime - ISO8601 formatted poll search end time (datetime)
	# dictConfig - social media client framework configuration file (dict)
	#
	# Return: bEndTimeReached boolean value indicating that poll search end time has been reached
	# Exception: thrown if validation of any function parameters will fail
	#
	def poll_search_end_time_reached( self, strSocialMediaType, listJSONItems, datetimePollEndTime, dictConfig ) :
		# store return Value
		bEndTimeReached = False

		# perform general validation checks
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ):
			raise Exception( 'expected social media type to be a string/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if not isinstance( listJSONItems, list ) :
			raise Exception( 'expected list of social media json items to be a list, but got ' + str( type( listJSONItems ) ) )
		if not isinstance( datetimePollEndTime, datetime.datetime ) :
			raise Exception( 'expected poll search end time to be a datetime, but got ' + str( type( datetimePollEndTime ) ) )

		if len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be empty' )

		# make sure that we are dealing with supported social media type
		self.validate_social_media_type( strSocialMediaType, dictConfig )

		# make sure that we are dealing with ISO8601 formatted timestamp for poll search end time
		# note: if exception will be raised it will mean that poll search end time was invalid or not ISO8601 formatted
		strPollEndTime = time_helper.format_iso_datetime( datetimePollEndTime )


		# handle special case when passed listJSONItems is an empty list -> in this case we will return False (there will be no evidence that poll search end time has
		# been reached)
		if len( listJSONItems ) == 0 :
			self.logger.warn( 'could not find any social media json items (poll search end time check is aborting)' )

			return False

		self.logger.debug( 'start comparing if any of social media json items have reached poll search end time ' + strPollEndTime )


		# process list of social media json items and determine whether poll search end time has been reached
		for jsonItem in listJSONItems :
			# store datetime object that will be compared
			datetimeCurentTimestamp = None

			# get timestamp depending on social media type
			try :
				self.logger.debug( 'trying to get ' + strSocialMediaType + ' timestamp from ' + repr( jsonItem ) )

				# get timestamp (already ISO8601 formatted) from current json item
				datetimeCurentTimestamp = self.get_timestamp( jsonItem, strSocialMediaType )

				if datetimeCurentTimestamp == None :
					raise Exception( 'timestamp was none (was it a correct json object?)' )

			# handle any exceptions and continue to next json item (if any)
			except :
				if strSocialMediaType == 'facebook' :
					return

				self.logger.warn( 'failed to get timestamp from json object ' + repr( jsonItem ) + ', reason: ' + str( sys.exc_info()[ 1 ] ) )

				# continue to next object
				continue

			# log debug information
			self.logger.debug( 'start comparing json item timestamp ' + str( time_helper.format_iso_datetime( datetimeCurentTimestamp ) + ' with poll search end time ' + str( time_helper.format_iso_datetime( datetimePollEndTime ) ) ) )

			# finally compare timestamps
			if datetimeCurentTimestamp >= datetimePollEndTime :
				self.logger.debug( 'poll search end time has been reached (current social media json item timestamp ' + str( time_helper.format_iso_datetime( datetimeCurentTimestamp ) ) + ', poll search end time ' + str( time_helper.format_iso_datetime( datetimePollEndTime ) ) )

				# set return flag to true
				bEndTimeReached = True

				# break the function (not need for any other checks)
				break

			else :
				self.logger.debug( 'poll search end time has not been reached (current social media json item timestamp ' + str( time_helper.format_iso_datetime( datetimeCurentTimestamp ) ) + ', poll search end time ' + str( time_helper.format_iso_datetime( datetimePollEndTime ) ) )


		# return boolean flag
		return bEndTimeReached



	#
	# another helper method (for conveinience only) that will allo to compare poll start and end time
	#
	# method will be used to compare poll start and end times i.e. if poll start time is larger that poll end time then this will incicate
	# that we need to stop poll search
	#
	# datetimePollStartTime - poll start datetime (datetime)
	# datetimePollEndTime - poll end datetime (datetime)
	#
	# Return: bPollStartTimeExceededEndTime boolean flag that will indicate that poll start time exceeded poll end time and we need to stop poll search
	# Exception: thrown if datetime verification of datetime objects will fail (i.e. not datetime objects, not ISO8601 formatted etc.)
	#
	def poll_search_start_time_exceeded_end_time( self, datetimePollStartTime, datetimePollEndTime ) :
		# store return value
		bPollStartTimeExceededEndTime = False

		# perform core validation checks
		if not isinstance( datetimePollStartTime, datetime.datetime ) :
			raise Exception( 'expected poll start time to be a datetime, but got ' + str( type( datetimePollStartTime ) ) )
		if not isinstance( datetimePollEndTime, datetime.datetime ) :
			raise Exception( 'expected poll end time to be a datetime, but got ' + str( type( datetimePollEndTime ) ) )

		# make sure that we are dealing with ISO8601 formatted timestamps
		time_helper.format_iso_datetime( datetimePollStartTime )
		time_helper.format_iso_datetime( datetimePollEndTime )

		# check if start datetime is less than end datetime
		if datetimePollStartTime >= datetimePollEndTime :
			bPollStartTimeExceededEndTime = True

		# return boolean flag
		return bPollStartTimeExceededEndTime



	#
	# helper method that will help to determine whether list of social media objects was none or empty
	#
	# note: main reason for the method is to have a 'one-liner' that will return boolean True or False incudating whether we want
	# to process list of json objects of not
	#
	# listJSONItems - list of social media items (list)
	# 
	# Exception: thrown if passed objects in not a list
	#
	def list_can_be_processed( self, listJSONItems ) :
		# store return value
		bListIsReadyToBeProcessed = False

		# check whether the list if none or empty
		if listJSONItems != None and len( listJSONItems ) > 0 :
			bListIsReadyToBeProcessed = True

		# return boolean flag indicating whether we can process a list (i.e. it is a list that is not None or empty)
		return bListIsReadyToBeProcessed


	#
	# helper method that will allow to record social media handler information into the database
	#
	# strHandlerId - social media handler id (str)
	# psqlHelper - PostgreSQL helper (PostgresqlHelper)
	# rmqHandler - RabbitMQ handler (RabbitMQHandler)
	# strAction -  action to perform on social media handler record i.e. close or delete
	# strMessage - message (optional) that will indicate additional information when social media handler will
	# be closed (i.e. was closed because its finished or failed for some reason)
	# loggerSocialMediaHandler - social media handler logger object (will be needed to remove all handlers) (logging.logger)
	#
	# Exception: thrown if fails to close rmq and/or posgresql connection
	#
	def tear_down( self, strHandlerId, psqlHelper, rmqHandler, strAction, httpServerEndpoint, strMessage = '', loggerSocialMediaHandler = None, fileHandler = None ) :

		# validate tear down options
		if not isinstance( strHandlerId, str ) and not isinstance( strHandlerId, unicode ) :
			raise Exception( 'expected social media handler to be string/unicode, but got ' + str( type( strHandlerId ) ) )
		if not isinstance( strAction, str ) and not isinstance( strAction, unicode ) :
			raise Exception( 'expected social media handler database action (i.e. close or delete) to be a string/unicode, but got ' + str( type( strAction ) ) )

		# validate social media handler database action
		if strAction != 'close' and strAction != 'delete' :
			raise Exception( 'invalid social media handler database table tear down action ' + str( strAction ) + ' (valid actions are \'close\' and \'delete\')' )


		self.logger.debug( 'start tear down' )
		self.logger.debug( 'requested operation: ' + strAction + ' handler' )

		# delete handler from the main HTTPEndpoint dictHandler
		if strHandlerId in httpServerEndpoint.get_dicthandler() :
			threadHandler = httpServerEndpoint.get_dicthandler()[ strHandlerId ]
			threadHandler.handlerThread = None
			del httpServerEndpoint.get_dicthandler()[ strHandlerId ]

		# handler will be stopped at this stage (normal teardown procedure will continue though)
		self.logger.info( 'handler ' + repr(strHandlerId) + ' was stopped successfully' )

		# if psqlHelper is not none then close/delete social media handler from the databse 
		# and close postgresql connection
		if psqlHelper is not None :
			# close of delete handler
			try :
				# close the handler
				if strAction == 'close' :
					psqlHelper.db_close_handler( strHandlerId, strMessage )

				else :
					psqlHelper.db_delete_handler( strHandlerId )

			except :
				self.logger.warn( 'failed to delete handler [' + strHandlerId + '] from the database (' + str( sys.exc_info()[1] ) + ')' )

			# close handler
			try :
				psqlHelper.close()
				self.logger.debug( 'posgresql helper connection was closed' )

			except :
				raise Exception( 'failed to close postgres connection (' + str( sys.exc_info()[1] ) + ')' )

		# close rabbitmq connection
		if rmqHandler is not None :
			try :
				rmqHandler.disconnect()
				self.logger.debug( 'rabbitmq handler connection was closed' )
			except :
				self.logger.warn( 'failed to close rabbitmq connection (' + str( sys.exc_info()[1] ) + ')' )

		# explicitly close and remove handlers (especially necessary to close and remove file handler)
		if loggerSocialMediaHandler is not None :
			for handler in loggerSocialMediaHandler.handlers[:] :
				try:
					handler.close()
					loggerSocialMediaHandler.removeHandler(handler)

				except:
					self.logger.warn('failed to close/delete logger handler ' + repr(sys.exc_info()[1]))

		# close file handler
		if fileHandler is not None :
			try :
				fileHandler.close()
			except :
				self.logger.warn( 'failed to close file handler : ' + str( sys.exc_info()[1] ) )

		# ackwonwledge that the tear down has finished
		self.logger.debug( 'tear down finished' )


	#
	# NOTE: depricated and will be removed in the future
	#
	# helper method that will allow to get specific URL parameter value from specified URL
	#
	# i.e.
	#
	# lets say we would like to get URL parameter limit value from this URL http://localhost:8001?limit=500, then current method
	# will parse URL and will return 100
	#
	def get_parameter_from_url( self, strURL, strURLParam ) :
		# store return value
		strURLParamValue = ''

		# validate strURL
		if not isinstance( strURL, str ) and not isinstance( strURL, unicode ) :
			raise Exception( 'expected URL to be a string/unicode, but got ' + str( type( strURL ) ) )
		if not isinstance( strURLParam, str ) and not isinstance( strURLParam, unicode ) :
			raise Exception( 'expected requested URL parameter to be a string/unicode, but got ' + str( type( strURLParam ) ) )

		if len( strURL ) == 0 :
			raise Exception( 'URL can not be empty' )
		if len( strURLParam ) == 0 :
			raise Exception( 'URL can not be empty' )

		# make sure that we are not trying to search anything that does not make any sense
		# TODO: probably need to find a lib that will handle multiple choices
		if strURLParam == '?' or strURLParam == '&' :
			raise Exception( 'URL parameter to search should not be equal to ? or &' )

		# check if URL contains URL parameters i.e. parameters after ?
		if '?' in strURL :
			listURLSplit = strURL.split( '?' )
			strURLParams = listURLSplit[ 1 ]


			if len( strURLParams ) != 0 :
				# split URL parameters on '&'
				listNextResultsTempSplit = strURLParams.split( '&' )

				# loop over the split results and populate new requests
				for strResutParam in listNextResultsTempSplit :
					# first of all split the result on '='
					listResultParamSplit = strResutParam.split("=")

					strRequestKey = listResultParamSplit[ 0 ]
					strRequestValue = listResultParamSplit[ 1 ]

					if strRequestKey == strURLParam :
						strURLParamValue = strRequestValue

						# break the loop as any futher processing is not required
						break

			else :
				self.logger.error( 'URL parameters are missing from ' + strURL + ' (URL parameters should be specified after ? delimited i.e. http://localhost:8000?limit=100) (search for ' + strURLParam + ' URL parameter is aborted)' )

		else :
			self.logger.error( 'could not find URL parameters in specified URL: ' + strURL + ' (search for ' + strURLParam + ' URL parameter is aborted)' )

		# return requested parameter value
		return strURLParamValue



	# helper method that will allow to to determine what page id url identifier to use when searching through pages
	# note: it will be based on the target api that will be submitted by social media client framework
	#
	# strSocialMediaClientTarget
	#
	def determine_instagram_target_endpoint( self, strSocialMediaClientTargetApi, dictConfig, strPageTypeIdentifier = 'next_page' ) :
		# store return value
		strInstagramPageURLIdentifier = ''

		# first of all make sure that dictConfig is a valid dict
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected social media client framework configuration file to be a dict, but got ' + str( type( dictConfig ) ) )
		if len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration file can not be empty' )

		if strPageTypeIdentifier == 'next_page' :
			# then make sure that instagram_next_page_id_url_identifier is actually present
			# note: values will be needed if we will be searching results using paging
			if 'instagram_next_page_id_url_identifier' not in dictConfig :
				raise Exception( 'instagram next page id url identifier (i.e. instagram_next_page_id_url_identifier) was not found in the main configuration file' )
			else :
				# make sure that at least 'default' instagram social media page id url identificator was specified
				if 'default' not in dictConfig[ 'instagram_next_page_id_url_identifier' ] :
					raise Exception( 'default instagram next page id url identifier (i.e. default) was not specified' )
				if dictConfig[ 'instagram_next_page_id_url_identifier' ][ 'default' ] == None or len( dictConfig[ 'instagram_next_page_id_url_identifier' ][ 'default' ] ) == 0 :
					raise Exception( 'default instagram next page id url identifier (i.e. default) can not be none or empty' )

		elif strPageTypeIdentifier == 'previous_page' :
			# then make sure that instagram_previous_page_id_url_identifier is actually present
			# note: values will be needed if we will be searching results using paging
			if 'instagram_previous_page_id_url_identifier' not in dictConfig :
				raise Exception( 'instagram previous page id url identifier (i.e. instagram_previous_page_id_url_identifier) was not found in the main configuration file' )
			else :
				# make sure that at least 'default' instagram social media page id url identificator was specified
				if 'default' not in dictConfig[ 'instagram_previous_page_id_url_identifier' ] :
					raise Exception( 'default instagram previous page id url identifier (i.e. default) was not specified' )
				if dictConfig[ 'instagram_previous_page_id_url_identifier' ][ 'default' ] == None or len( dictConfig[ 'instagram_previous_page_id_url_identifier' ][ 'default' ] ) == 0 :
					raise Exception( 'default instagram previous page id url identifier (i.e. default) can not be none or empty' )


		# proceed with social media target api parsing
		# if strSocialMediaClientTargetApi is none or empty then simply use default page url identifier
		if strSocialMediaClientTargetApi == None or len( strSocialMediaClientTargetApi ) == 0 :
			self.logger.debug( 'social media api_target was empty (returning default page url identifier)' )

			if strPageTypeIdentifier == 'next_page' :
				strInstagramPageURLIdentifier = dictConfig[ 'instagram_next_page_id_url_identifier' ][ 'default' ]
			else :
				strInstagramPageURLIdentifier = dictConfig[ 'instagram_previous_page_id_url_identifier' ][ 'default' ]

		# process the value
		else :
			self.logger.debug( 'trying to get Instagram API endpoint value from social media target_api: ' + strInstagramPageURLIdentifier )

			if '/' in strSocialMediaClientTargetApi :
				listTempSocialMediaTargetAPiSplit = strSocialMediaClientTargetApi.split( '/' )

				# we are only interested in first part of the list i.e. tags/london (inerested in tags only)
				strInstagramApi = listTempSocialMediaTargetAPiSplit[ 0 ]

				# if for some reason its none or empty then return default page url identifier
				if strInstagramApi == None or len( strInstagramApi ) == 0 :
					self.logger.debug( 'social media api_target was empty (returning default page url identifier)' )

					if strPageTypeIdentifier == 'next_page' :
						strInstagramPageURLIdentifier = dictConfig[ 'instagram_next_page_id_url_identifier' ][ 'default' ]
					else :
						strInstagramPageURLIdentifier = dictConfig[ 'instagram_previous_page_id_url_identifier' ][ 'default' ]

				# try to find it in the dict
				else :
					if strInstagramApi in dictConfig[ 'instagram_next_page_id_url_identifier' ] :
						self.logger.debug( 'trying to get page url identifier for a specific Instagram API endpoint ' + strInstagramApi )

						if strPageTypeIdentifier == 'next_page' :
							strInstagramPageURLIdentifier = dictConfig[ 'instagram_next_page_id_url_identifier' ][ strInstagramApi ]
						else :
							strInstagramPageURLIdentifier = dictConfig[ 'instagram_previous_page_id_url_identifier' ][ strInstagramApi ]
					else :
						self.logger.debug( 'could not find requested page url identifier ' + strInstagramApi + ' in ' + repr( dictConfig[ 'instagram_next_page_id_url_identifier' ] ) + ' (returning default value)' )

						if strPageTypeIdentifier == 'next_page' :
							strInstagramPageURLIdentifier = dictConfig[ 'instagram_next_page_id_url_identifier' ][ 'default' ]
						else :
							strInstagramPageURLIdentifier = dictConfig[ 'instagram_previous_page_id_url_identifier' ][ 'default' ]

			# social media request api_target did not contain /
			else :
				if strSocialMediaClientTargetApi in dictConfig[ 'instagram_next_page_id_url_identifier' ] :
					self.logger.debug( 'trying to get page url identifier for a specific Instagram API endpoint ' + strInstagramApi )

					if strPageTypeIdentifier == 'next_page' :
						strInstagramPageURLIdentifier = dictConfig[ 'instagram_next_page_id_url_identifier' ][ strSocialMediaClientTargetApi ]
					else :
						strInstagramPageURLIdentifier = dictConfig[ 'instagram_previous_page_id_url_identifier' ][ strSocialMediaClientTargetApi ]
				else :
					self.logger.debug( 'could not find requested page url identifier ' + strSocialMediaClientTargetApi + ' in ' + repr( dictConfig[ 'instagram_next_page_id_url_identifier' ] ) + ' (returning default value)' )

					if strPageTypeIdentifier == 'next_page' :
						strInstagramPageURLIdentifier = dictConfig[ 'instagram_next_page_id_url_identifier' ][ 'default' ]
					else :
						strInstagramPageURLIdentifier = dictConfig[ 'instagram_previous_page_id_url_identifier' ][ 'default' ]

		if strPageTypeIdentifier == 'next_page' :
			self.logger.debug( 'returning next page url identifier value: ' + strInstagramPageURLIdentifier )
		else :
			self.logger.debug( 'returning previous page url identifier value: ' + strInstagramPageURLIdentifier )

		# return page url identifier
		return strInstagramPageURLIdentifier


	#
	# helper method for social media thread poll requests that will help to check whether media object is between start and end times
	# list of items that can still be processed
	#
	# strSocialMediaType - social media type e.g. twitter, youtube etc. (str)
	# listJSONItems - list of social media query result content items (list)
	# datetimePollStartTime - ISO8601 formatted poll search start time (datetime)
	# datetimePollEndTime - ISO8601 formatted poll search end time (datetime)
	# dictConfig - social media client framework configuration file (dict)
	#
	# Return: listNotExpiredSocialMediaItems list of social media items that has not expired
	# Exception: thrown if validation of any function parameters will fail
	#
	def return_not_expired_media_items( self, strSocialMediaType, listJSONItems, datetimePollStartTime, datetimePollEndTime, dictConfig ) :
		# store return Value
		listNotExpiredSocialMediaItems = []

		# perform general validation checks
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ) :
			raise Exception( 'expected social media type to be a string/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if not isinstance( listJSONItems, list ) :
			raise Exception( 'expected list of social media json items to be a list, but got ' + str( type( listJSONItems ) ) )
		if not isinstance( datetimePollStartTime, datetime.datetime ) :
			raise Exception( 'expected poll search start time to be a datetime, but got ' + str( type( datetimePollStartTime ) ) )
		if not isinstance( datetimePollEndTime, datetime.datetime ) :
			raise Exception( 'expected poll search end time to be a datetime, but got ' + str( type( datetimePollEndTime ) ) )

		if len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be empty' )

		# make sure that we are dealing with supported social media type
		self.validate_social_media_type( strSocialMediaType, dictConfig )

		# make sure that we are dealing with ISO8601 formatted timestamp for poll search end time
		# note: if exception will be raised it will mean that poll search end time was invalid or not ISO8601 formatted
		strPollStartTime = time_helper.format_iso_datetime( datetimePollStartTime )
		strPollEndTime = time_helper.format_iso_datetime( datetimePollEndTime )


		# handle special case when passed listJSONItems is an empty list -> in this case we will return False (there will be no evidence that poll search end time has
		# been reached)
		if len( listJSONItems ) == 0 :
			self.logger.debug( 'could not find any social media json items (poll search end time check is aborting)' )

			# return empty list
			return listNotExpiredSocialMediaItems

		self.logger.debug( 'start filtering social media items between poll start time ' + strPollStartTime + ' and poll end time ' + strPollEndTime + ' (note: only social media items between ' + strPollStartTime + ' and ' + strPollEndTime + ' will be processed)' )


		# process list of social media json items and determine whether poll search end time has been reached
		for jsonItem in listJSONItems :
			# store datetime object that will be compared
			datetimeCurentTimestamp = None

			# get timestamp depending on social media type
			self.logger.debug( 'trying to get ' + strSocialMediaType + ' timestamp from ' + repr( jsonItem ) )

			# get timestamp (already ISO8601 formatted) from current json item
			datetimeCurentTimestamp = self.get_timestamp( jsonItem, strSocialMediaType )

			# if timestamp is none then add item as it is (some of them wont have timestamp, like facebook user page!)
			if datetimeCurentTimestamp == None :
				self.logger.warn( 'timestamp was none (adding item without time filtering)' )

				listNotExpiredSocialMediaItems.append( jsonItem )

				# continue to the next object (if any)
				continue


			# log debug information
			self.logger.debug( 'start comparing whether current media item is between poll start ' + str( time_helper.format_iso_datetime( datetimePollStartTime ) ) + ' and poll end times ' + str( time_helper.format_iso_datetime( datetimePollEndTime ) ) + ' (timestamp of media item: ' + str( time_helper.format_iso_datetime( datetimeCurentTimestamp ) ) + ')' )

			# finally compare timestamps
			if datetimeCurentTimestamp >= datetimePollStartTime and datetimeCurentTimestamp <= datetimePollEndTime :
				self.logger.debug( 'poll search item is between poll start ' + str( time_helper.format_iso_datetime( datetimePollStartTime ) ) + ' and poll end times ' + str( time_helper.format_iso_datetime( datetimePollEndTime ) ) + ' (timestamp of media item: ' + str( time_helper.format_iso_datetime( datetimeCurentTimestamp ) ) + ')' )

				# add social media item to the list
				listNotExpiredSocialMediaItems.append( jsonItem )

			else :
				self.logger.debug( 'poll search item is not between poll start ' + str( time_helper.format_iso_datetime( datetimePollStartTime ) ) + ' and poll end times ' + str( time_helper.format_iso_datetime( datetimePollEndTime ) ) + ' (timestamp of media item: ' + str( time_helper.format_iso_datetime( datetimeCurentTimestamp ) ) + ')' )
				self.logger.debug( 'note: this item will not be processed' )

				# continue to next media object
				continue


		# return list of social media items that are not expired
		return listNotExpiredSocialMediaItems


	# helper method that will return control exchange configuration dict with all necessary parameters
	#
	# strRMQExchange - rabbitmq exchange (str)
	# strRMQRouting = rabbimq routing (str)
	# dictConfig - social media client framework configuration file (dict)
	#
	# Return dictControlExchangeParams configuration dict with all necessary rabbitmq configuration parameters
	# Exception: thrown if any of the core parameters will be invalid or missing
	#
	def get_rmq_control_exchange_parameters( self, strRMQExchange, strRMQRouting, dictConfig ) :
		# store return value
		dictControlExchangeParams = {}

		# perform core checks
		if not isinstance( strRMQExchange, str ) and not isinstance( strRMQExchange, unicode ) :
			raise Exception( 'expected rmq exchange value to be a string/unicode, but got ' + str( type( strRMQExchange ) ) )
		if not isinstance( strRMQRouting, str ) and not isinstance( strRMQRouting, unicode ) :
			raise Exception( 'expected rmq routing value to be a string/unicode, but got ' + str( type( strRMQRouting ) ) )
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected social media client framework configuration to be a dict, but got ' + str( type( dictConfig ) ) )

		if len( strRMQExchange ) == 0 :
			raise Exception( 'rmq exchange value can not be empty' )
		if len( strRMQRouting ) == 0 :
			raise Exception( 'rmq routing value can not be empty' )
		if len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration can not be empty' )


		# check social media client framework configuration file
		# check for core rmq parameters
		if 'rmq_host' not in dictConfig :
			raise Exception( 'rmq host (i.e. rmq_host) was not specified in the main social media client framework configuration file' )
		if 'rmq_port' not in dictConfig :
			raise Exception( 'rmq port (i.e. rmq_port) was not specified in the main social media client framework configuration file' )
		if 'rmq_username' not in dictConfig :
			raise Exception( 'rmq username (i.e. rmq_username) was not specified in the main social media client framework configuration file' )
		if 'rmq_password' not in dictConfig :
			raise Exception( 'rmq password (i.e. rmq_password) was not specified in the main social media client framework configuration file' )

		# check for core rmq control channel parameters
		if 'control_rmq_exchange' not in dictConfig :
			raise Exception( 'rmq control exchange (i.e. control_rmq_exchange) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_routing' not in dictConfig :
			raise Exception( 'rmq control routing (i.e. control_rmq_routing) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_queue_name' not in dictConfig :
			raise Exception( 'rmq control queue name (i.e. control_rmq_queue_name) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_exchange_type' not in dictConfig :
			raise Exception( 'rmq control exchange type (i.e. control_rmq_exchange_type) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_exclusive_queue' not in dictConfig :
			raise Exception( 'rmq control exclusive queue boolean flag (i.e. control_rmq_exclusive_queue) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_auto_delete_queue' not in dictConfig :
			raise Exception( 'rmq control auto delete queue boolean flag (i.e. control_rmq_auto_delete_queue) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_timeout_statement' not in dictConfig :
			raise Exception( 'rmq control timeout statement (i.e. control_rmq_timeout_statement) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_timeout_connection' not in dictConfig :
			raise Exception( 'rmq control timeout connection (i.e. control_rmq_timeout_connection) was not specified in the main social media client framework configuration file' )
		if 'control_rmq_timeout_overall' not in dictConfig :
			raise Exception( 'rmq control timeout overalln (i.e. control_rmq_timeout_overall) was not specified in the main social media client framework configuration file' )

		if dictConfig[ 'control_rmq_exchange' ] == None or len( dictConfig[ 'control_rmq_exchange' ] ) == 0 :
			raise Exception( 'rmq control exchange (i.e. control_rmq_exchange) can not be empty' ) 
		if dictConfig[ 'control_rmq_routing' ] == None or len( dictConfig[ 'control_rmq_routing' ] ) == 0 :
			raise Exception( 'rmq control routing (i.e. control_rmq_routing) can not be empty' )
		if dictConfig[ 'control_rmq_queue_name' ] == None or len( dictConfig[ 'control_rmq_queue_name' ] ) == 0 :
			raise Exception( 'rmq control queue name (i.e. control_rmq_queue_name) can not be empty' )
		if dictConfig[ 'control_rmq_exchange_type' ] == None or len( dictConfig[ 'control_rmq_exchange_type' ] ) == 0 :
			raise Exception( 'rmq control exchange type (i.e. control_rmq_exchange_type) can not be empty' )
		if dictConfig[ 'control_rmq_exclusive_queue' ] == None or len( dictConfig[ 'control_rmq_exclusive_queue' ] ) == 0 :
			raise Exception( 'rmq control exclusive queue boolean flag (i.e. control_rmq_exclusive_queue) can not be empty' )
		if dictConfig[ 'control_rmq_auto_delete_queue' ] == None or len( dictConfig[ 'control_rmq_auto_delete_queue' ] ) == 0 :
			raise Exception( 'rmq control auto delete queue boolean flag (i.e. control_rmq_auto_delete_queue) can not be empty' )
		if dictConfig[ 'control_rmq_timeout_statement' ] == None or len( dictConfig[ 'control_rmq_timeout_statement' ] ) == 0 :
			raise Exception( 'rmq control timeout statement (i.e. control_rmq_timeout_statement) can not be empty' )
		if dictConfig[ 'control_rmq_timeout_connection' ] == None or len( dictConfig[ 'control_rmq_timeout_connection' ] ) == 0 :
			raise Exception( 'rmq control timeout connection (i.e. control_rmq_timeout_connection) can not be empty' )
		if dictConfig[ 'control_rmq_timeout_overall' ] == None or len( dictConfig[ 'control_rmq_timeout_overall' ] ) == 0 :
			raise Exception( 'rmq control timeout overalln (i.e. control_rmq_timeout_overall) can not be empty' )

		# create control exchange and routing
		# note: control exchange and routing values will be appended to existing exchange and routing values
		#
		# i.e.
		#
		# if exchange value was test_exchange then control exchange will be test_exchange_control (same idea for routing)
		#
		strControlRMQExchange = strRMQExchange + dictConfig[ 'control_rmq_exchange' ]
		strControlRMQRouting = strRMQRouting + dictConfig[ 'control_rmq_routing' ]

		# read all necessary rmq core and control parameters
		strControlRMQHost = dictConfig[ 'rmq_host' ]
		nControlRMQPort = int( dictConfig[ 'rmq_port' ] )
		strControlRMQUser = dictConfig[ 'rmq_username' ]
		strControlRMQPass = dictConfig[ 'rmq_password' ]
		
		# Ensure ASCII encoding of RabbitMQ config
		strControlRMQHost = confToASCII( strControlRMQHost )
		strControlRMQUser = confToASCII( strControlRMQUser )
		strControlRMQPass = confToASCII( strControlRMQPass )

		# read rmq queue name and exchange type
		strControlRMQQueue = dictConfig[ 'control_rmq_queue_name' ]
		strControlRMQExchangeType = dictConfig[ 'control_rmq_exchange_type' ]

		# check control queue name (if it's string value is none, then need to set the queue value to python None)
		if strControlRMQQueue.lower() == 'none' :
			strControlRMQQueue = None

		# check control rmq queue exclusive flag 
		bControlRMQExclusiveQueue = False
		if dictConfig[ 'control_rmq_exclusive_queue' ].lower() == 'true' :
			bControlRMQExclusiveQueue = True
		elif dictConfig[ 'control_rmq_exclusive_queue' ].lower() == 'false' :
			bControlRMQExclusiveQueue = False
		else :
			raise Exception( 'rmq control exclusive queue [control_rmq_exclusive_queue] ' + 
				'can be true or false, but not ' + str( dictConfig[ 'control_rmq_exclusive_queue' ] ) )

		# check control rmq queue auto-delete flag
		bControlRMQAutoDeleteQueue = False
		if dictConfig[ 'control_rmq_auto_delete_queue' ].lower() == 'true' :
			bControlRMQAutoDeleteQueue = True
		elif dictConfig[ 'control_rmq_auto_delete_queue' ].lower() == 'false' :
			bControlRMQAutoDeleteQueue = False
		else :
			raise Exception( 'rmq control autodelete queue [control_rmq_auto_delete_queue] ' + 
				'can be true or false, but not ' + str( dictConfig[ 'control_rmq_auto_delete_queue' ] ) )

		# read timeout statements
		nControlRMQTimeoutStatement = int( dictConfig[ 'control_rmq_timeout_statement' ] )
		nControlRMQTimeoutConnection = int( dictConfig[ 'control_rmq_timeout_connection' ] )
		nControlRMQTimeoutOverall = int( dictConfig[ 'control_rmq_timeout_overall' ] )


		# store rmq core and control values into the dict
		dictControlExchangeParams[ 'control_rmq_host' ] = strControlRMQHost
		dictControlExchangeParams[ 'control_rmq_port' ] = nControlRMQPort
		dictControlExchangeParams[ 'control_rmq_username' ] = strControlRMQUser
		dictControlExchangeParams[ 'control_rmq_password' ] = strControlRMQPass
		dictControlExchangeParams[ 'control_rmq_exchange' ] = strControlRMQExchange
		dictControlExchangeParams[ 'control_rmq_routing' ] = strControlRMQRouting
		dictControlExchangeParams[ 'control_rmq_queue_name' ] = strControlRMQQueue
		dictControlExchangeParams[ 'control_rmq_exchange_type' ] = strControlRMQExchangeType
		dictControlExchangeParams[ 'control_rmq_exclusive_queue' ] = bControlRMQExclusiveQueue
		dictControlExchangeParams[ 'control_rmq_auto_delete_queue' ] = bControlRMQAutoDeleteQueue
		dictControlExchangeParams[ 'control_rmq_timeout_statement' ] = nControlRMQTimeoutStatement
		dictControlExchangeParams[ 'control_rmq_timeout_connection' ] = nControlRMQTimeoutConnection
		dictControlExchangeParams[ 'control_rmq_timeout_overall' ] = nControlRMQTimeoutOverall


		# return rmq control dict with all necessary parameters
		return dictControlExchangeParams



	# helper method that will allow to generate social media handler control messages (i.e. when starting, finishing etc.)
	#
	# note: return JSON control dict structure
	# 
	# {
	# 	"id" : "facebook_55",
	# 	"status" : "started successfully at 2016-02-01T11:53:28+00:00"
	# 	"timestamp_utc" : "2016-02-01T11:53:28+00:00"
	# 	"timestamp_unix" : 1454327608
	# 	"items" : 55
	# }
	# 
	#
	#
	# strHandlerId - social media handler id e.g. facebook_55 (str)
	# strMessage - social media handler status message e.g. notification of start or error etc. (str)
	# strStatusMessageType - status message type i.e. status or error (str)
	# nTotalNumberOfItems - total number of items [note: if will be set to -1 then it it will not be used] (int)
	#
	# Return: dictJSONControlMessage dictionary containing core control message values
	# Exception: thrown if any of function parameters will be invalid
	#
	def generate_rmq_control_message( self, strHandlerId, strMessage, strStatusMessageType, nTotalNumberOfItems ) :
		# store return dict
		dictJSONControlMessage = {}

		# validate function parameters
		if not isinstance( strHandlerId, str ) and not isinstance( strHandlerId, unicode ) :
			raise Exception( 'expected social media handler id to be a string/unicode, but got ' + str( type( strHandlerId ) ) )
		if not isinstance( strMessage, str ) and not isinstance( strMessage, unicode ) :
			raise Exception( 'expected social media control status message to be a string/unicode, but got ' + str( type( strMessage ) ) )
		if not isinstance( strStatusMessageType, str ) and not isinstance( strStatusMessageType, unicode ) :
			raise Exception( 'expected social media control status message type to be a string/unicode, but got ' + str( type( strStatusMessageType ) ) )
		if not isinstance( nTotalNumberOfItems, int ) :
			raise Exception( 'expected social media control message number of received items to be an int, but got ' + str( type( nTotalNumberOfItems ) ) )

		if len( strHandlerId ) == 0 :
			raise Exception( 'social media handler id can not be empty' )
		if len( strMessage ) == 0 :
			raise Exception( 'social media control status message can not be empty' )
		if len( strStatusMessageType ) == 0 :
			raise Exception( 'social media control status message type can not be empty' )

		if strStatusMessageType != 'status' and strStatusMessageType != 'error' :
			raise Exception( 'invalid social media control status message type ' + strStatusMessageType + ' (valid values are status or error)' )

		# generate timestamps (both ISO8601 UTC and UNIX formatted)
		datetimeTimestampUTC = self.generate_iso_timestamp_datetime()
		strTimestampUTC = self.generate_iso_timestamp_str()
		nTimestampUnix = self.convert_utc_datetime_to_unix( datetimeTimestampUTC )

		# populate dict with necessary control message values
		dictJSONControlMessage[ 'id' ] = strHandlerId
		dictJSONControlMessage[ 'timestamp_utc' ] = strTimestampUTC
		dictJSONControlMessage[ 'timestamp_unix' ] = nTimestampUnix

		if strStatusMessageType == 'status' :
			dictJSONControlMessage[ 'status' ] = strMessage
		else :
			dictJSONControlMessage[ 'error' ] = strMessage

		# in some cases when number of items will be irrelevant information (i.e. during an error message) its value will be set to -1
		# in this case items field will be empty
		if nTotalNumberOfItems != -1 :
			dictJSONControlMessage[ 'items' ] = nTotalNumberOfItems

		# return dict containing handler control values
		return dictJSONControlMessage


	#
	# helper method that will process rmq control message (i.e. generate json message and publish it to control exchange)
	# note: other methods will be able to use a one liner to process the message
	#
	# bControlRMQEnabled - boolean flag indicating whether rmq message control processing is enabled or not (bool)
	# rmqControlHandler - rmq control handler (RabbitMQHandler)
	# strHandlerId - social media handler id that will be requesting to process a control message (str)
	# strMessage - control message (str)
	# strMessageType - control message type (i.e. status or error) (str)
	# nReceivedItems - number of received items (-1 will indicate the received items field should not be included in the error message such as in most of the error messages) (int)
	#
	def process_rmq_control_message( self, bControlRMQEnabled, rmqControlHandler, strHandlerId, strMessage, strMessageType, nReceivedItems ) :
		# send error status message to controm rmq (if appropriate)
		if bControlRMQEnabled == True :
			# generate control message
			jsonControlMessage = self.generate_rmq_control_message( strHandlerId, strMessage, strMessageType, nReceivedItems )


			# publish control message
			# note: publish timeout value is currently hardcoded
			rmqControlHandler.publish_message( json.dumps( jsonControlMessage, ensure_ascii = False, encoding = 'utf-8' ), timeout = 3600 )

		else :
			self.logger.warn( 'requested to process rmq control message, but flag to process control messages was set to false in the main social media client framework configuration file (i.e. control_rmq_enabled)' )
			self.logger.warn( 'control message will not be processes (ignoring)' )



	#
	# helper method that will convert ISO8601 UTC formatted timestamp to UNIX timestamp
	#
	# strDatetimeUTC - ISO8601 UTC formatted timestamp (str)
	#
	# Return: nUnixFormattedTimestamp UNIX formatted timestamp
	# Exception: thrown if datetime object will not be an instance of datetime, as well as if its format will be invalid
	def convert_utc_datetime_to_unix( self, datetimeUTC ) :
		# store return value
		nUnixFormattedTimestamp = 0

		# validate datetimestamp
		if not isinstance( datetimeUTC, datetime.datetime ) :
			raise Exception( 'expected ISO8601 UTC formatted datetime object to be a datetime, but got ' + str( type( datetimeUTC ) ) )

		# use time_helper library to validate datetime format
		# note: exception will be thrown if datetime object format will be invalid or unsupported
		time_helper.format_iso_datetime( datetimeUTC )

		# finally convert ISO8601 UTC formatted datetime object to UNIX timestamp
		nTempUnixFormattedTimestamp = time.mktime( datetimeUTC.timetuple() )

		# remove float value from the end of the result timestap i.e. remove 0.0
		nUnixFormattedTimestamp = int( nTempUnixFormattedTimestamp )

		# return UNIX formatted timestamp
		return nUnixFormattedTimestamp


	#
	# helper message that will generate ISO8601 UTC formatted timestamp based on current time (string representation)
	# note: this method will be mainly used by a RMQ control handler
	#
	# Return: strTimestampUTC ISO8601 UTC formatted timestamp as string
	#
	def generate_iso_timestamp_str( self ) :
		# store returned value
		strTimestampUTC = ''

		# generate datetime and format it
		datetimeNow = time_helper.convert_datetime_tz_iso( datetime.datetime.now() )
		strTimestampISO = time_helper.format_iso_datetime( datetimeNow )

		# return generated string
		return strTimestampISO

	#
	# helper message that will generate ISO8601 UTC formatted timestamp based on current time (datetime representation)
	# note: this method will be mainly used by a RMQ control handler
	#
	# Return: datetimeNowUTC ISO8601 UTC formatted timestamp as datetime
	def generate_iso_timestamp_datetime( self ) :
		# store returned value
		datetimeNowUTC = ''

		# generate datetime and format it
		datetimeNowUTC = time_helper.convert_datetime_tz_iso( datetime.datetime.now() )

		# return generated string
		return datetimeNowUTC


	#
	# helper method that will indicate whether it will be necessary to sort list of social media items (i.e. asc based on time)
	# note: sorting social media items is mainly useful during one off social media requests (NOT with polling requests as they will be already sorted in their own way)
	#
	# strSocialMediaType - social media type (str)
	# dictConfig - main social media client framework configuration file (dict)
	#
	def bool_sort_social_media_items( self, strSocialMediaType, dictConfig ) :
		# store return boolean value
		bSortSocialMediaItems = False

		# validate social function parameters
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ) :
			raise Exception( 'expected social media type to be a str/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected social media client framework configuration file to be a dict, but got ' + str( type( dictConfig ) ) )

		if len( dictConfig ) == 0 :
			raise Exception( 'social media client framework configuration file can not be empty' )

		# validate social media type
		

		# validate social media type
		self.validate_social_media_type( strSocialMediaType, dictConfig )

		# check if <social_media_handler>_sort_social_media_items was set to true
		strBooleanFlagId = strSocialMediaType + '_sort_social_media_items'

		if strBooleanFlagId in dictConfig :
			self.logger.debug( strBooleanFlagId + ' was specified in the main social media client framework configuration file (checking its value)' )

			# get boolean flag value
			strBooleanFlagValue = dictConfig[ strBooleanFlagId ]


			# note: we will only deal with str values here (for simplicity)
			if not isinstance( strBooleanFlagValue, str ) and not isinstance( strBooleanFlagValue, unicode ) :
				raise Exception( 'expected ' + strBooleanFlagId + ' boolean flag to be a str/unicode (valid values are true and false), but got ' + str( type( strBooleanFlagValue ) ) )


			# check the value
			if strBooleanFlagValue == None and len( strBooleanFlagValue ) == 0 : 
				self.logger.warn( strBooleanFlagId + ' boolean id was specified but its value was none or empty (must be set to true or false)' )

			else :
				if strBooleanFlagValue.lower() == 'true' :
					bSortSocialMediaItems = True

					self.logger.debug( strBooleanFlagId + ' was set to true (i.e. request to sort social media result items on each request)' )

				else :
					if strBooleanFlagValue.lower() == 'false' : 
						self.logger.debug( strBooleanFlagId + ' was set to false (i.e. request NOT to sort social media result items on each request)' )

					else :
						self.logger.warn( strBooleanFlagId + ' was set to invalid value ' + strBooleanFlagValue + ' (valid values are true or false)')

		# return boolean flag
		return bSortSocialMediaItems



	#
	# helper method that will get earliest (i.e. older) timestamp from the list of JSON items
	#
	# strSocialMediaType - social media type (str)
	# listJSONItems - list of JSON items (list)
	# dictConfig - main social media client framework configuration file (dict)
	# bReturnTimestampOnly - boolean flag indicating to return timestamp only (default True) (bool)
	#
	def get_earliest_social_media_item( self, strSocialMediaType, listJSONItems, dictConfig, bReturnTimestampOnly = True ) :
		# store return values (some of them will be used)
		objReturnValue = None
		jsonEarliestSocialMediaItem = {}
		datetimeEarliestTimestamp = None

		# validate function parameters
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ) :
			raise Exception( 'expected social media type to be a str/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if not isinstance( listJSONItems, list ) :
			raise Exception( 'expected list of JSON social media items to be list, but got ' + str( type( listJSONItems ) ) )
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected main social media client framework configuration file to be a dict, but got ' + str( type( dictConfig ) ) )

		if len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be none or empty' )
		if len( listJSONItems ) == 0 :
			raise Exception( 'list of JSON social media items can not be empty' )
		if len( dictConfig ) == 0 :
			raise Exception( 'main social media client framework configuration file can not be none or empty' )


		# as a final check validate social media type
		self.validate_social_media_type( strSocialMediaType, dictConfig)

		# log debug statement
		self.logger.debug( 'trying to get latest timestamp from a list of JSON items for ' + strSocialMediaType + ' (starting)' )


		for dictJSONItem in listJSONItems :
			# get timestamp for current social media item
			datetimeCurrentItemTimestamp = self.get_timestamp( dictJSONItem, strSocialMediaType )

			if datetimeCurrentItemTimestamp == None :
				self.logger.warn( 'failed to get timestamp from ' + json.dumps( dictJSONItem, ensure_ascii = False, encoding = 'utf-8' ) )

				# continue to next json item (if any)
				continue

			# get string datetime representation (mainly for debug messages)
			strDatetimeCurrentItemTimestamp = time_helper.format_iso_datetime( datetimeCurrentItemTimestamp )

			# log debug message
			self.logger.debug( 'comparing timestamp ' + strDatetimeCurrentItemTimestamp )

			# compare timestamps
			# initially store timestamp
			if datetimeEarliestTimestamp == None :
				datetimeEarliestTimestamp = datetimeCurrentItemTimestamp

				# log debug statement
				self.logger.debug( 'setting initial timestamp for comparison ' + strDatetimeCurrentItemTimestamp )
				self.logger.debug( 'storing earliest json object to be: ' + json.dumps( dictJSONItem, ensure_ascii = False, encoding = 'utf-8' ) )

				# actually store latest social media item
				jsonEarliestSocialMediaItem = dictJSONItem

			else :
				# convert earliest timestamp value (i.e. old earliest) to string representation (for debug purposes only)
				strDatetimeEarliestTimestamp = time_helper.format_iso_datetime( datetimeEarliestTimestamp )

				if datetimeCurrentItemTimestamp < datetimeEarliestTimestamp :
					self.logger.debug( 'found earlier timestamp ' + strDatetimeCurrentItemTimestamp + ' (old earliest timestamp value ' + strDatetimeEarliestTimestamp + ')' )

					# update earliest timestamp
					datetimeEarliestTimestamp = datetimeCurrentItemTimestamp

					# log debug statement
					self.logger.debug( 'storing earliest json object to be: ' + json.dumps( dictJSONItem, ensure_ascii = False, encoding = 'utf-8' ) )

					# actually store latest social media item
					jsonEarliestSocialMediaItem = dictJSONItem

				else :
					self.logger.debug( 'current timestamp ' + strDatetimeCurrentItemTimestamp + ' is not earlier than previously defined earliest timestamp ' + strDatetimeEarliestTimestamp + ' (ignoring)' )


		if datetimeEarliestTimestamp == None :
			self.logger.warn( 'could not find any timestamp(s) (returning empty string)' )

			# set return value to be an empty string (its check already defined on social media handlers)
			objReturnValue = ''

		else :
			# check what we are going to return (i.e. timestamp only or full social media item)
			if bReturnTimestampOnly == True :
				objReturnValue = time_helper.format_iso_datetime( datetimeEarliestTimestamp )

				# log debug statement
				self.logger.debug( 'returning earliest social media item timestamp value only (bReturnTimestampOnly = True) : ' + objReturnValue )

			else :
				objReturnValue = jsonEarliestSocialMediaItem

				# log debug statement
				self.logger.debug( 'returning earliest social media item (bReturnTimestampOnly = False) : ' + json.dumps( objReturnValue, ensure_ascii = False, encoding = 'utf-8' ) )


		# return value (datetime string OR json object)
		return objReturnValue


	#
	# helper method that will get latest (i.e. recent) timestamp from the list of JSON items
	#
	# strSocialMediaType - social media type (str)
	# listJSONItems - list of JSON items (list)
	# dictConfig - main social media client framework configuration file (dict)
	# bReturnTimestampOnly - boolean flag indicating to return timestamp only (default True) (bool)
	#
	def get_latest_social_media_item( self, strSocialMediaType, listJSONItems, dictConfig, bReturnTimestampOnly = True ) :
		# store return values (some of them will be used)
		objReturnValue = None
		jsonLatestSocialMediaItem = {}
		datetimeLatestTimestamp = None

		# validate function parameters
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ) :
			raise Exception( 'expected social media type to be a str/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if not isinstance( listJSONItems, list ) :
			raise Exception( 'expected list of JSON social media items to be list, but got ' + str( type( listJSONItems ) ) )
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected main social media client framework configuration file to be a dict, but got ' + str( type( dictConfig ) ) )

		if len( strSocialMediaType ) == 0 :
			raise Exception( 'social media type can not be none or empty' )
		if len( listJSONItems ) == 0 :
			raise Exception( 'list of JSON social media items can not be empty' )
		if len( dictConfig ) == 0 :
			raise Exception( 'main social media client framework configuration file can not be none or empty' )


		# as a final check validate social media type
		self.validate_social_media_type( strSocialMediaType, dictConfig)

		# log debug statement
		self.logger.debug( 'trying to get latest timestamp from a list of JSON items for ' + strSocialMediaType + ' (starting)' )


		for dictJSONItem in listJSONItems :
			# get timestamp for current social media item
			datetimeCurrentItemTimestamp = self.get_timestamp( dictJSONItem, strSocialMediaType )

			if datetimeCurrentItemTimestamp == None :
				self.logger.warn( 'failed to get timestamp from ' + json.dumps( dictJSONItem, ensure_ascii = False, encoding = 'utf-8' ) )

				# continue to next json item (if any)
				continue

			# get string datetime representation (mainly for debug messages)
			strDatetimeCurrentItemTimestamp = time_helper.format_iso_datetime( datetimeCurrentItemTimestamp )

			# log debug message
			self.logger.debug( 'comparing timestamp ' + strDatetimeCurrentItemTimestamp )

			# compare timestamps
			# initially store timestamp
			if datetimeLatestTimestamp == None :
				datetimeLatestTimestamp = datetimeCurrentItemTimestamp

				# log debug statement
				self.logger.debug( 'setting initial timestamp for comparison ' + strDatetimeCurrentItemTimestamp )
				self.logger.debug( 'storing latest json object to be: ' + json.dumps( dictJSONItem, ensure_ascii = False, encoding = 'utf-8' ) )

				# actually store latest social media item
				jsonLatestSocialMediaItem = dictJSONItem

			else :
				# convert earliest timestamp value (i.e. old earliest) to string representation (for debug purposes only)
				strDatetimeLatestTimestamp = time_helper.format_iso_datetime( datetimeLatestTimestamp )

				if datetimeCurrentItemTimestamp > datetimeLatestTimestamp :
					self.logger.debug( 'found latest timestamp ' + strDatetimeCurrentItemTimestamp + ' (old earliest timestamp value ' + strDatetimeLatestTimestamp + ')' )

					# update earliest timestamp
					datetimeLatestTimestamp = datetimeCurrentItemTimestamp

					# log debug statement
					self.logger.debug( 'storing latest json object to be: ' + json.dumps( dictJSONItem, ensure_ascii = False, encoding = 'utf-8' ) )

					# actually store latest social media item
					jsonLatestSocialMediaItem = dictJSONItem

				else :
					self.logger.debug( 'current timestamp ' + strDatetimeCurrentItemTimestamp + ' is not later than previously defined latest timestamp ' + strDatetimeLatestTimestamp + ' (ignoring)' )


		if datetimeLatestTimestamp == None :
			self.logger.warn( 'could not find any timestamp(s) (returning empty string)' )

			# set return value to be an empty string (its check already defined on social media handlers)
			objReturnValue = ''

		else :
			# check what we are going to return (i.e. timestamp only or full social media item)
			if bReturnTimestampOnly == True :
				objReturnValue = time_helper.format_iso_datetime( datetimeLatestTimestamp )

				# log debug statement
				self.logger.debug( 'returning latest social media item timestamp value only (bReturnTimestampOnly = True) : ' + objReturnValue )

			else :
				objReturnValue = jsonLatestSocialMediaItem

				# log debug statement
				self.logger.debug( 'returning latest social media item (bReturnTimestampOnly = False) : ' + json.dumps( objReturnValue, ensure_ascii = False, encoding = 'utf-8' ) )


		# return value (datetime string OR json object)
		return objReturnValue


	#
	# helper method that will sort and parse next page results
	#
	# dictMetadata - metadata json that includes next page results etc. (dict)
	# strSocialMediaType - social media type i.e. twitter, facebook (str)
	#
	# Return: dictUrlParams encoded url parameters from parsed next results
	#
	def generate_next_request_url_params( self, dictMetadata, strSocialMediaType, strNextPageIdentifier, strPreviousPageIdentifier ) :
		# store return value
		dictUrlParams = {}

		# validate inputs
		if not isinstance( dictMetadata, dict ) :
			raise Exception( 'expected metadata json object to be a dict, but got ' + str( type( dictMetadata ) ) )
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ) :
			raise Exception( 'expected social media type to be a string/unicode, but got ' + str( type( strSocialMediaType ) ) )


		# start checking results meta data
		if strSocialMediaType == 'twitter' :
			if 'search_metadata' in dictMetadata :
				if 'next_results' in dictMetadata[ 'search_metadata' ] :
					# start parsing next url -> call helper method that will parse it to the dict
					strNextUrl = dictMetadata[ 'search_metadata' ][ 'next_results' ]

					# store parsed next url results into a temp dict
					dictUrlParams = self.generate_url_param_dict( str( strNextUrl ) )

					# also check if min id was specified in newly generated dict, if not check it in actual pagination metadata
					if strPreviousPageIdentifier in dictUrlParams :
						self.logger.debug( 'found ' + strPreviousPageIdentifier + ' in automatically generated next page dict ' + repr( dictUrlParams ) + ' (using that value)' )

					# check pagination if previous page token was not automatically returned
					elif strPreviousPageIdentifier in dictMetadata[ 'search_metadata' ] :
						# store previous page value
						strPreviousPageValue = dictMetadata[ 'search_metadata' ][ strPreviousPageIdentifier ]

						if int( strPreviousPageValue ) > 0 :
							self.logger.debug( 'found previous page token in next results metadata dict ' + repr( dictMetadata[ 'search_metadata' ] ) + ' (using that value)' )

							# store previous page value
							dictUrlParams[ strPreviousPageIdentifier ] = strPreviousPageValue

						else :
							self.logger.debug( 'previous page token value was 0 (ignoring)' )

				else :
					self.logger.error( 'next_results was not found in the next results metadata: ' + repr( dictMetadata ) )

			else :
				self.logger.error( 'no search_metadata was found in next results metadata: ' + repr( dictMetadata ) )


		elif strSocialMediaType == 'youtube' :
			raise Exception( 'not implemented' )

		elif strSocialMediaType == 'facebook' :
			raise Exception( 'not implemented' )

		elif strSocialMediaType == 'instagram' :
			if 'pagination' in dictMetadata :
				if 'next_url' in dictMetadata[ 'pagination' ] :
					# start parsing next url -> call helper method that will parse it to the dict
					strNextUrl = dictMetadata[ 'pagination' ][ 'next_url' ]

					# store parsed next url results into a temp dict
					dictUrlParams = self.generate_url_param_dict( str( strNextUrl ) )

					# also check if min id was specified in newly generated dict, if not check it in actual pagination metadata
					if strPreviousPageIdentifier in dictUrlParams :
						self.logger.debug( 'found ' + strPreviousPageIdentifier + ' in automatically generated next page dict ' + repr( dictUrlParams ) + ' (using that value)' )

					# check pagination if previous page token was not automatically returned
					elif strPreviousPageIdentifier in dictMetadata[ 'pagination' ] :
						# store previous page value
						strPreviousPageValue = dictMetadata[ 'pagination' ][ strPreviousPageIdentifier ]

						self.logger.debug( 'found previous page token in next results metadata dict ' + repr( dictMetadata[ 'pagination' ] ) + ' (using that value)' )

						# store previous page value
						dictUrlParams[ strPreviousPageIdentifier ] = strPreviousPageValue

				else :
					self.logger.error( 'next url was not found in the next results metadata: ' + repr( dictMetadata ) )
			else :
				self.logger.error( 'no pagination was found in next results metadata: ' + repr( dictMetadata ) )

		# URL encode all parameters before return
		for strKey in dictUrlParams :
			if (isinstance( dictUrlParams[ strKey ], ( unicode ) ) ) :
				dictUrlParams[ strKey ] = unicode( dictUrlParams[ strKey ] ).encode( 'utf-8' )
			else :
				dictUrlParams[ strKey ] = dictUrlParams[ strKey ]

		# return url encoded dict
		return dictUrlParams


	#
	#
	# helper method that will fetch url parameters from url string
	#
	# strURL - url string (str)
	#
	# Return: dictUrlParams dict containing url parameters
	#
	def generate_url_param_dict( self, strURL ) :
		# store return value
		dictUrlParams = {}

		# validate the input
		if not isinstance( strURL, str ) and not isinstance( strURL, unicode ) :
			raise Exception( 'expected url to be a string/unicode, but got ' + str( type( strURL ) ) )

		# make sure that url is not empty
		if len( strURL ) == 0 :
			raise Exception( 'url can not be empty' )

		# check if URL contains URL parameters i.e. parameters after ?
		if '?' in strURL :
			listURLSplit = strURL.split( '?' )
			strURLParams = listURLSplit[ 1 ]


			if len( strURLParams ) != 0 :
				# split URL parameters on '&'
				listNextResultsTempSplit = strURLParams.split( '&' )

				# loop over the split results and populate new requests
				for strResutParam in listNextResultsTempSplit :
					# first of all split the result on '='
					listResultParamSplit = strResutParam.split("=")

					strRequestKey = listResultParamSplit[ 0 ]
					strRequestValue = listResultParamSplit[ 1 ]

					# finally store results in the dict
					dictUrlParams[ strRequestKey ] = strRequestValue

			else :
				self.logger.error( 'URL parameters are missing from ' + strURL + ' (URL parameters should be specified after ? delimited i.e. http://localhost:8000?limit=100)' )

		else :
			self.logger.error( 'could not find URL parameters in specified URL: ' + strURL  )


		# return dict containing url params
		return dictUrlParams


	#
	# helper method that will check whether we need to publish raw media item to the RabbitMQ
	#
	# note: this option is enabled by default (i.e. set to true) in the main configuration file
	#
	# dictConfig - main social media lcient framework configuration file (dict)
	#
	# Return: bResult boolean true if we will publish raw social media item to RabbitMQ, false otherwise
	#
	def bool_publish_raw_social_items( self, dictConfig ) :
		# store return value
		bResult = True # => note: in this case its default return value is true

		# validate function input
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected main social media configuration file or request configuration body to be a dict, but got ' + str( type( dictConfig ) ) )

		# start looking for the needed value
		if 'publish_raw_content_items_to_rmq' in dictConfig :
			# get the value of publish_content_items_to_rmq
			strPublishRawCintentItemsToRMQ = str( dictConfig[ 'publish_raw_content_items_to_rmq' ] ).lower()

			if strPublishRawCintentItemsToRMQ == 'false' :
				self.logger.warn( 'instructed NOT to publish raw social media content to RabbitMQ (i.e. publish_raw_content_items_to_rmq = false)' )

				# set result to false
				bResult = False

			elif strPublishRawCintentItemsToRMQ == 'true' :
				self.logger.debug( 'instructed to publish raw social media content to RabbitMQ (i.e. publish_raw_content_items_to_rmq = true)' )

				# set result to True
				bResult = True

			else :
				self.logger.error( 'invalid publish_raw_content_items_to_rmq value was specified: ' + strPublishRawCintentItemsToRMQ + ' (valid values are true or false)' )

		else :
			self.logger.debug( 'publish_raw_content_items_to_rmq was not specified in the main configuration file or request configuration body (will be using default configuration from the main social media client framework configuration file)' )

		# return result Value
		return bResult


	#
	# helper method that will check whether we need to log raw media item to the file
	#
	# dictConfig - main social media lcient framework configuration file (dict)
	#
	# Return: bResult boolean true if we will log raw social media item to file
	#
	def bool_log_raw_social_items( self, dictConfig ) :
		# store return value
		bResult = False

		# validate function input
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected main social media configuration file request configuration body to be a dict, but got ' + str( type( dictConfig ) ) )

		# start looking for the needed value
		if 'log_raw_content_items_to_file' in dictConfig :
			# get the value of log_raw_content_items_to_file
			strLogRawCintentItemsToFile = str( dictConfig[ 'log_raw_content_items_to_file' ] ).lower()

			if strLogRawCintentItemsToFile == 'true' :
				self.logger.debug( 'instructed to log raw social media content to file (i.e. log_raw_content_items_to_file = true)' )

				# set result to true
				bResult = True

			elif strLogRawCintentItemsToFile == 'false' :
				self.logger.debug( 'instructed NOT to log raw social media content to file (i.e. log_raw_content_items_to_file = false)' )

				# set result to false
				bResult = False

			else :
				self.logger.error( 'invalid log_raw_content_items_to_file value was specified: ' + strLogRawCintentItemsToFile + ' (valid values are true or false)' )

		else :
			self.logger.debug( 'log_raw_content_items_to_file was not specified in the main configuration file or request configuration body (will be using default configuration from the main social media client framework configuration file)' )

		# return result Value
		return bResult



	#
	# helper method that will initialise raw social media logger file handler
	#
	# strFileDirName - file directory name where all raw social media content items will be logged (str)
	# strSocialMediaType - social media type i.e. twitter, youtube etc. (str)
	# dictConfig - main social media configuration file (dict)
	#
	# note: for now file name where all war content items will be logged will be equal to exhange value + social media type
	# i.e. test_exhange_twitter.log
	#
	# Return fileHandler file handler that will be used to write raw social media content items
	#
	def initialise_raw_content_item_file_handler( self, strFileDirName, strSocialMediaType, dictConfig ) :
		# store return value
		fileHandler = None

		# validate input values
		if not isinstance( strFileDirName, str ) and not isinstance( strFileDirName, unicode ) :
			raise Exception( 'expected social media raw file folder name to be a string/unicode, but got ' + str( type( strFileDirName ) ) )
		if not isinstance( strSocialMediaType, str ) and not isinstance( strSocialMediaType, unicode ) :
			raise Exception( 'excpected social media type to be a string/unicode, but got ' + str( type( strSocialMediaType ) ) )
		if not isinstance( dictConfig, dict ) :
			raise Exception( 'expected main social media configuration file to be a dict, but got ' + str( type( dictConfig ) ) )

		# check core parameters
		if not 'logging_dir' in dictConfig :
			raise Exception( 'logging_dir was not found in the main configuration file (ignoring)' )
		else :
			self.logger.debug( 'found logging directory ' + dictConfig[ 'logging_dir' ] )

		# store logging directory
		strLogDirectory = dictConfig[ 'logging_dir' ]

		# make sure that logging directoiry exists
		if not os.path.exists( strLogDirectory ) :
			raise Exception( 'logging directory ' + strLogDirectory + ' does not exist' )
		else :
			self.logger.debug( 'logging directory ' + strLogDirectory + ' exists (processing)' )

		# create separate logging directoty that is equal to exchange
		strRawLogFilesDir = strLogDirectory + os.path.sep + strFileDirName

		# check if location actually exists, if not create it
		if not os.path.exists( strRawLogFilesDir ) :			
			os.makedirs( strRawLogFilesDir )

			self.logger.info( 'created a directory where raw social media content fwill be stored: ' + strRawLogFilesDir )

		# create a file name
		# i.e. foldername_social_media_type.log
		strRawLogFilesDirFileName = strRawLogFilesDir + os.path.sep + strFileDirName + '_' + strSocialMediaType + '.log'

		# check if file already exist
		if os.path.exists( strRawLogFilesDirFileName ) :
			self.logger.info( 'file ' + strRawLogFilesDirFileName + ' already exist (will continue to populate it)' )

			# open file with append
			fileHandler = codecs.open( strRawLogFilesDirFileName, 'a', encoding = 'utf-8' )

		else :
			self.logger.info( 'file ' + strRawLogFilesDirFileName + ' does not exist (creating...)' )

			# create new file
			fileHandler = codecs.open( strRawLogFilesDirFileName, 'w', encoding = 'utf-8' )


		# return file handler name
		return fileHandler


	#
	# main method that will be used to handle social media handler (all of them) error messages
	#
	def process_error_message( self, httpResponse, strSocialMediaType, strHandlerId, nItemsFound, rmqControlHandler, bControlRMQEnabled, strSpecificErrorType = 'default' ) :
		# store method variables
		strMessage = ''
		strErrorTimestamp = self.generate_iso_timestamp_str()

		# determine error message i.e. fetch text from json or use plain text (depending on what will be supplied in the error message)
		# first of all try to get message value as json encoded text
		bJSONErrorMessageFound = False
		try :
			strMessage = json.dumps( httpResponse.json(), ensure_ascii = False, encoding = 'utf-8' )

			# indicate that we actually found error message in JSON response object
			bJSONErrorMessageFound = True

		except :
			self.logger.warn( 'failed to get error message text from JSON http response object : ' + str( sys.exc_info()[1] ) + ' (will try to use plain error text value)' )

		# if JSON error message was not found in the response then we will try to get it as plain text
		if bJSONErrorMessageFound == False :
			try :
				strMessage = str( httpResponse.text )

			except :
				self.logger.warn( 'failed to get plain error message text from http response object (will try to use http response message representation as error message)' )

				# set error text to be a representation of the http response object (not other choices)
				strMessage = 'no specific error details were specified'


		# set default error message if error text will be empty#
		if len( strMessage ) == 0 :
			strMessage = 'no specific error details were specified'

		# log warning notification message
		self.logger.warn( strSocialMediaType + ' handler error occured (will try to handle it): ' + strMessage )


		#
		# start handling error messages
		#
		# first of all handle general error messages based on response codes
		#
		# handle "Bad Request" (e.g. HTTP/1.1 400) - raise exception and write the log (not much you can do with Bad Request error)
		if httpResponse.status_code == 400 :
			raise Exception(  'query response was HTTP 400 (Bad Request) (' + strMessage + ')' )


		# handle "not authorised" (e.g. HTTP/1.1 401) - raise exception and write the log (not much you can do with Not Authorised error)
		elif httpResponse.status_code == 401 :
			raise Exception( 'query response was HTTP 401 (Not Authorised) (' + strMessage + ')' )

		# handle "Not Found" request (e.g. HTTP/1.1 404) - raise exception and write the log (not much you can do with Not Found error)
		elif httpResponse.status_code == 404 :
			raise Exception( 'query response was HTTP 404 (Not Found) (' + strMessage + ')' )

		# handle "Request Timeout" (e.g. HTTP/1.1 408)
		elif httpResponse.status_code == 408 :
			# create a control message (also used in the log)
			strMessage = 'query response was HTTP 408 (Request Timeout), will retry to execute the query again (last update at: ' + strErrorTimestamp + ')'

		# handle HTTP 420 or 429 i.e. "Too Many Requests" (mainly used by Twitter)
		# note: no futher processing should be made
		elif httpResponse.status_code == 420 or httpResponse.status_code == 429 :
			raise Exception( 'query response was HTTP ' + str( httpResponse.status_code ) + ' (Too Many Requests) (' + strMessage + ')' )

		# handle "Internal Server Error" (e.g. HTTP/1.1 500)
		elif httpResponse.status_code == 500 :
			# create a control message (also used in the log)
			strMessage = 'query response was HTTP 500 (Internal Server Error) with error message ' + strMessage + ', will retry to execute the query again (last update at: ' + strErrorTimestamp + ')'

		# handle "Bad Gateway" (e.g. HTTP/1.1 502)
		elif httpResponse.status_code == 502 :
			# create a control message (also used in the log)
			strMessage = 'query response was HTTP 502 (Bad Gateway) with error message ' + strMessage + ', will retry to execute the query again (last update at: ' + strErrorTimestamp + ')'

		# handle "Service Unavailable" (e.g. HTTP/1.1 503)
		elif httpResponse.status_code == 503 :
			strMessage = 'query response was HTTP 503 (Service Unavailable) with error message ' + strMessage + ', will retry to execute the query again (last update at: ' + strErrorTimestamp + ')'

		# Handler "Gateway Timeout" (e.g. HTTP/1.1 504)
		elif httpResponse.status_code == 504 : 
			# create a control message (also used in the log)
			strMessage = 'query response was HTTP 504 (Gateway Timeout), will retry to execute the query again (last update at: ' + strErrorTimestamp + ')'

		# process exception if no error code will be found
		# note: helper variable will be used in this case to determine the type of error such as connection errors etc.
		else :
			if strSpecificErrorType == 'connection_error' :
				strMessage = 'connection error occurred, will retry to execute the query again (last update at: ' + strErrorTimestamp + ')'

			# since we are dealing with unknown (or not processed error message) we will stop here
			else :
				raise Exception( 'query response failed with HTTP ' + str( httpResponse.status_code ) + ' (' + strMessage + ')' )


		#
		# if we are dealing with non critical errors then we will process this block (i.e. log error message and process error control message)
		#
		# log common error message
		self.logger.error( strMessage )

		# send error message acknowledgment
		self.process_rmq_control_message( bControlRMQEnabled, rmqControlHandler, strHandlerId, strMessage, 'error', nItemsFound )


	#
	# helper method that will check if social media search/stream crawler was requested to return specific number of content items
	# note: content items restriction will be mainly used when we would like to restrict users on how many content items should be
	# returned i.e. find 10000 content items and stop
	#
	# strTotalAllowedItemsDictKey - key id that will be used to find total number of allower items value in the dictionary (str)
	# dictConfig - main configuration file (dict)
	# dictArguments - dictionary of arguments that will be checked wheter total number restrictions was specified (dict)
	#
	# Return nTotalNumberOfAllowedItems integer value (default -1) indicating how many items are allowed
	#
	# Exception thorn of dictArguments will not be a dict, if number of items to return is not an interer as well as strTotalAllowedItemsId
	# will be none or empty
	#
	def get_total_number_of_allowed_items( self, dictConfig, dictArguments ) :
		# store default return values (-1)
		# note: if returned value will be equal to -1 then handler will simply ignore it assuming that allowed items counter
		# was never specified
		nTotalNumberOfAllowedItems = -1

		# make sure that dictArguments is actually a dict
		if not isinstance( dictArguments, dict ) :
			self.logger.warn( 'expected request arguments object to be a dict. but got ' + str( type( dictArguments ) ) )
			self.logger.warn( 'ignoring total allowed items check and continue' )

			# return default value
			return nTotalNumberOfAllowedItems


		# default value of the key will be total_number_of_items
		strTotalAllowedItemsDictKey = 'total_number_of_items_dict_key'
		if 'total_number_of_items_dict_key' in dictConfig :
			if dictConfig['total_number_of_items_dict_key'] == None or len( dictConfig['total_number_of_items_dict_key'] ) == 0 :
				self.logger.debug( 'total_number_of_items_dict_key value was empty, using default value of ' + strTotalAllowedItemsDictKey )
			else :
				strTotalAllowedItemsDictKey = str( dictConfig['total_number_of_items_dict_key'] )

		else :
			self.logger.debug( 'total_number_of_items_dict_key value was not specified, using default value of ' + strTotalAllowedItemsDictKey )


		# if dictArguments is actually a dict then continue and check if specified dict key id was not none or empty
		if strTotalAllowedItemsDictKey == None or len( strTotalAllowedItemsDictKey ) == 0 :
			self.logger.warn( 'total allowed items dict key id value was none or empty' )
			self.logger.warn( 'ignoring total allowed items check and continue' )

			# return default value
			return nTotalNumberOfAllowedItems

		# log debug statement
		self.logger.debug( 'trying to find allowed items dictionary key ' + str( strTotalAllowedItemsDictKey ) + ' in ' + repr( dictArguments ) )

		# try to get the value
		try :
			if strTotalAllowedItemsDictKey in dictArguments :
				self.logger.debug( 'found total allowed item dict key id ' + strTotalAllowedItemsDictKey + ' in ' + repr( dictArguments ) + ' (trying to fetch its value)' )

				if dictArguments[strTotalAllowedItemsDictKey] == None or len( str( dictArguments[strTotalAllowedItemsDictKey] ) ) == 0 :
					raise Exception( 'total number of allowed items was specified, but its value was none or empty' )

				else :
					nTotalNumberOfAllowedItems = int( dictArguments[strTotalAllowedItemsDictKey] )

			else :
				raise Exception( 'total allowed items dict key ' + strTotalAllowedItemsDictKey + ' was not found' )


		except :
			self.logger.warn( 'failed to get/parse total allowed items from request arguments (reason: ' + str( sys.exc_info()[1] ) + ')' )
			self.logger.warn( 'ignoring total allowed items check and continue' )

			# return default value
			return nTotalNumberOfAllowedItems

		# log simply information statement
		self.logger.debug( 'found allowed items count ' + str( nTotalNumberOfAllowedItems ) + '(handler only return that amount of content items and stop)' )

		# finally return the value if all the above operations were successful
		return nTotalNumberOfAllowedItems

def confToASCII( conf ) :
	result = conf

	if isinstance( conf, unicode ) :
		dec = conf.decode("utf-8")
		result = dec.encode("ascii","ignore")

	return result

	'''