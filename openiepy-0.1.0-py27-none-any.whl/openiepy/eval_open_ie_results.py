# !/usr/bin/env python
# -*- coding: utf-8 -*-

"""
/////////////////////////////////////////////////////////////////////////
//
// (c) Copyright University of Southampton IT Innovation, 2018
//
// Copyright in this software belongs to IT Innovation Centre of
// Gamma House, Enterprise Road, Southampton SO16 7NS, UK.
//
// This software may not be used, sold, licensed, transferred, copied
// or reproduced in whole or in part in any manner or form or in or
// on any media by any person other than in accordance with the terms
// of the Licence Agreement supplied with the software, or otherwise
// without the prior written consent of the copyright owners.
//
// This software is distributed WITHOUT ANY WARRANTY, without even the
// implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE, except where stated in the Licence Agreement supplied with
// the software.
//
//    Created By :    Stuart E. Middleton
//    Created Date :    2018/07/31
//    Created for Project:    GRAVITATE
//
/////////////////////////////////////////////////////////////////////////
//
// Dependencies: None
//
/////////////////////////////////////////////////////////////////////////
"""

import os, sys, logging, traceback, codecs, datetime, copy, time, ast, math, re, random, shutil, json, csv, multiprocessing, subprocess
import soton_corenlppy

################################
# main
################################

# only execute if this is the main file
if __name__ == '__main__' :

	#
	# check args
	#
	if len(sys.argv) < 2 :
		print 'Usage: eval_open_ie_results.py <config file>\n'
		sys.stdout.flush()
		sys.exit(1)
	if not os.path.isfile(sys.argv[1]) :
		print '<config file> ' + sys.argv[1] + ' does not exist\n'
		sys.stdout.flush()
		sys.exit(1)

	# make logger (global to STDOUT)
	LOG_FORMAT = ('%(levelname) -s %(asctime)s %(message)s')
	logger = logging.getLogger( __name__ )
	logging.basicConfig( level=logging.INFO, format=LOG_FORMAT )
	logger.info('logging started')

	# initialize
	readHandle = None
	writeHandle = None

	try :
		# init
		strConfigFile = sys.argv[1]

		# load config
		dictConfig = soton_corenlppy.config_helper.read_config( strConfigFile )
		listEvalDatasets = dictConfig['eval_datasets']

		for strDataset in listEvalDatasets :

			logger.info( 'CORPUS : ' + strDataset + '\n' )

			# read the ground truth annotations in the dataset dir
			strGroundTruth = strDataset + os.sep + 'extractions-all-labelled.txt'
			if os.path.exists( strGroundTruth ) == False :
				raise Exception( 'ground truth file does not exist : ' + strGroundTruth )

			# read the ground truth data
			readHandle = codecs.open( strGroundTruth, 'r', 'utf-8', errors = 'replace' )
			listLines = readHandle.readlines()
			readHandle.close()

			listGroundTruth = []
			listSents = []
			nMaxSentID = -1
			for strLine in listLines :
				listComponents = strLine.rstrip('\n\r').split( '\t' )
				if len(listComponents) == 1 :
					listSents.append( listComponents[0] )
				elif len(listComponents) > 1 :
					# sent_index, [arg, rel, arg, context], 0|1
					# sent_index, [subj, attr_base, attr_prep, obj], 0|1
					# sent_index, [subj, attr], 0|1
					# sent_index, [subj], 0|1
					nSizeOfExtraction = len(listComponents) - 2
					if nSizeOfExtraction < 1 :
						raise Exception( 'invalid extraction in ground truth : ' + repr(listComponents) )
					
					# for clauseIE only force it to triples
					if strDataset in ['nyt-clauseIE','reverb-clauseIE','wikipedia-clauseIE'] :
						if nSizeOfExtraction > 3 :
							nSizeOfExtraction = 3
					listEntry = listComponents[0:nSizeOfExtraction+1]
					listEntry.append( listComponents[-1] )

					# remove quotes from both ends (not multiple, as text might have quotes in it)
					for nIndexEntry in range(1,nSizeOfExtraction+1) :
						listEntry[nIndexEntry] = listEntry[nIndexEntry][1:-1]

					# check numbers are ok
					try :
						listEntry[0] = int( listEntry[0] )
					except:
						raise Exception( 'ground truth sent_index not an integer : ' + repr(listComponents) )
					try :
						listEntry[ len(listEntry)-1 ] = int( listEntry[-1] )
					except:
						raise Exception( 'ground truth label not an integer : ' + repr(listComponents) )

					# add to list
					listGroundTruth.append( listEntry )

					if nMaxSentID < listEntry[0] :
						nMaxSentID = listEntry[0]

			logger.info( 'Number of sents in corpus = ' + str(len(listSents)) )
			logger.info( 'Number of ground truth entries in corpus = ' + str(len(listGroundTruth)) )
			if nMaxSentID != len(listSents)-1 :
				logger.warn( 'Max send ID ' + str(nMaxSentID) + ' != number of sents (we you missing labels?)' )

			# loop on each result set in the dataset dir
			listUnlabelledResult = []
			listFileSet = os.listdir( strDataset )
			for strFile in listFileSet :
				if (strFile.startswith( 'extractions-' )) and (strFile.count( '-all' ) == 0) :

					strResultFile = strDataset + os.sep + strFile
					if os.path.exists( strResultFile ) == False :
						raise Exception( 'result file does not exist : ' + strResultFile )

					logger.info( 'RESULT : ' + strResultFile )

					# read the result data
					readHandle = codecs.open( strResultFile, 'r', 'utf-8', errors = 'replace' )
					listLines = readHandle.readlines()
					readHandle.close()

					listResultData = []

					# openie5 and stanford have a different extraction format (semicolon delimited)
					# openie5
					#   CourtLink, which has 160 employees, developed a filing system that enables judges, lawyers and court clerks to process pleadings, motions and other documents electronically over a secure connection.
					#   0.90 (a filing system; enables; court clerks to other documents; electronically over a secure connection)
					# stanford oie
					#  C:\projects\gravitate\openie-data-papers\code\stanfordOpenIE\nyt-sentences.txt	1	she	author under	name of Kathryn Watterson Burkhart	8	9	19	21	22	27	1.000	A graduate of the University of Arizona , she is a lecturer in writing at Princeton University and an author under the name of Kathryn Watterson Burkhart .	DT NN IN DT NNP IN NNP , PRP VBZ DT NN IN VBG IN NNP NNP CC DT NN IN DT NN IN NNP NNP NNP .	she	author under	name of Kathryn Watterson Burkhart
					#
					if strFile.startswith('extractions-openie5') :
						nSentIndex = 0
						for strLine in listLines :
							if len( strLine.rstrip('\n\r') ) == 0 :
								# next sent
								nSentIndex = nSentIndex + 1
								continue
							if not strLine.startswith('0') :
								# ignore sent text
								continue
							if strLine.count('(') == 0 :
								# check for a bad file
								raise Exception('invalid openie5 result : ' + repr(strLine))

							strLineConf = strLine[ 0:strLine.index(' ') ]

							# handle context
							if strLine.count('))):') > 0 :
								strLineExtract = strLine[ strLine.index('))):(') + 5 : ].rstrip('\n\r)')
							else :
								strLineExtract = strLine[ strLine.index('(') + 1 : ].rstrip('\n\r)')
							listComponents = strLineExtract.split( ';' )

							if len(listComponents) < 3 :
								raise Exception('invalid openie5 extract result : ' + repr(listComponents))
							for nIndexComp in range(len(listComponents)) :
								listComponents[nIndexComp] = listComponents[nIndexComp].strip(' ')

							# merge any entailment to last arg
							for nIndexComp in range(3,len(listComponents)) :
								listComponents[2] = listComponents[2] + ' ' + listComponents[nIndexComp]
							listComponents = listComponents[0:3]

							listEntry = [ nSentIndex ]
							listEntry.extend( listComponents )
							listEntry.append( strLineConf )

							# check numbers are ok
							try :
								listEntry[ len(listEntry)-1 ] = float( listEntry[-1] )
							except:
								raise Exception( 'result file label not a float : ' + repr(listComponents) )

							# add to list
							listResultData.append( listEntry )

					elif strFile.startswith('extractions-stanfordoie') :
						for strLine in listLines :
							listComponents = strLine.rstrip('\n\r').split( '\t' )
							if len(listComponents) == 17 :
								# filename, sent_index, arg, rel, arg, ...
								listEntry = listComponents[ 1:5 ]
								listEntry.append( listComponents[11] )
								strSentText = listComponents[12]

								# check numbers are ok
								try :
									listEntry[0] = int( listEntry[0] )
								except:
									raise Exception( 'ground truth sent_index not an integer : ' + repr(listComponents) )
								try :
									listEntry[ len(listEntry)-1 ] = float( listEntry[-1] )
								except:
									raise Exception( 'result file label not a float : ' + repr(listComponents) )

								# add to list
								listResultData.append( listEntry )
							else :
								raise Exception( 'invalid stanford oie result : ' + repr( listComponents ) )

					# others use tab delimited results (any number of components is OK)
					#   Henry was Governor Edwin Washington Edwards's choice for Speaker.
					#   0	"Henry"	"was"	"Governor Edwin Washington Edwards 's choice"	0.9469705806066386
					else :
						for strLine in listLines :
							listComponents = strLine.rstrip('\n\r').split( '\t' )
							if len(listComponents) > 1 :
								# sent_index, [arg, rel, arg, context], float(score)
								# sent_index, [subj, attr_base, attr_prep, obj], float(score)
								# sent_index, [subj, attr], float(score)
								# sent_index, [subj], float(score)
								nSizeOfExtraction = len(listComponents) - 2
								if nSizeOfExtraction < 0 :
									raise Exception( 'invalid extraction in result file : ' + repr(listComponents) )

								# for clauseIE only force it to triples
								if strDataset in ['nyt-clauseIE','reverb-clauseIE','wikipedia-clauseIE'] :
									if nSizeOfExtraction > 3 :
										nSizeOfExtraction = 3
								listEntry = listComponents[0:nSizeOfExtraction+1]
								listEntry.append( listComponents[-1] )

								# remove quotes
								for nIndexEntry in range(1,nSizeOfExtraction+1) :
									listEntry[nIndexEntry] = listEntry[nIndexEntry].strip('"')

								# check numbers are ok
								try :
									listEntry[0] = int( listEntry[0] )
								except:
									raise Exception( 'ground truth sent_index not an integer : ' + repr(listComponents) )
								try :
									listEntry[ len(listEntry)-1 ] = float( listEntry[-1] )
								except:
									raise Exception( 'result file label not a float : ' + repr(listComponents) )

								# add to list
								listResultData.append( listEntry )

					logger.info( 'Number of result entries = ' + str(len(listResultData)) )

					# sort the result by score (higher score is better)
					listResultData = sorted( listResultData, key=lambda entry: entry[-1], reverse=True )

					# loop on each result and compute TP and FP
					# returning a yield when we have enough extractions
					targetYield = [ 100,200,400,600,800,1000,1200 ]
					nYield = 0
					nTP = 0
					nFP = 0
					listErrorResult = []

					for entryResult in listResultData :
						nSentIndex = entryResult[0]
						listTriple = entryResult[1:-1]
						nScore = entryResult[-1]

						#logger.info( 'T1 = ' + repr(entryResult) )

						# lookup result in the ground truth
						bFound = False
						for entryTruth in listGroundTruth :
							nSentIndexTruth = entryTruth[0]
							listTripleTruth = entryTruth[1:-1]
							nLabelTruth = entryTruth[-1]

							#if nSentIndexTruth == 0 :
							#	logger.info( 'T2 = ' + repr(entryTruth) )

							if (nSentIndex == nSentIndexTruth) and (listTriple == listTripleTruth) :
								if nLabelTruth == 1 :
									nTP = nTP + 1
									bFound = True
									break
								else :
									nFP = nFP + 1
									bFound = True

									# add to error list
									listErrorResultEntry = [ nSentIndex ]
									listErrorResultEntry.extend( listTriple )
									listErrorResult.append( listErrorResultEntry )
									break

						if bFound == False :
							listUnlabelledEntry = [ nSentIndex ]
							listUnlabelledEntry.extend( listTriple )
							listUnlabelledEntry.append( '?' )
							if not listUnlabelledEntry in listUnlabelledResult :
								listUnlabelledResult.append( listUnlabelledEntry )

						# have we got to a target yield threshold yet?
						if (nYield < len(targetYield)) and ((nTP + nFP) >= targetYield[nYield]) :

							# compute P@Yield
							if nFP + nTP == 0 :
								nP = 0.0
							else :
								nP = nTP / ( 1.0 * ( nFP + nTP ) )
							logger.info( 'P@' + str( nFP + nTP ) + ' = ' + str(nP) )

							# move to next yield
							nYield = nYield + 1

					# always report max yield result
					# compute P@Yield
					if nFP + nTP == 0 :
						nP = 0.0
					else :
						nP = nTP / ( 1.0 * ( nFP + nTP ) )
					logger.info( 'P@' + str( nFP + nTP ) + ' = ' + str(nP) )

					# write the errors to disk for a fault analysis
					if len(listErrorResult) > 0 :
						strErrorFile = strResultFile + '.errors.txt'
						logger.info( 'ERRORS : ' + strErrorFile )
						writeHandle = codecs.open( strErrorFile, 'w', 'utf-8', errors = 'replace' )

						for nIndex in range(len(listSents)) :
							writeHandle.write( listSents[nIndex] + '\n' )

							for entry in listErrorResult :
								nIndexEntry = entry[0]
								if nIndexEntry > len(listSents)-1 :
									raise Exception( 'error sent index out of range' )

								if nIndex == nIndexEntry :
									writeHandle.write( str(nIndexEntry) + '\t' )
									for strCol in entry[1:-1] :
										writeHandle.write( '"' + strCol + '"\t' )
									writeHandle.write( '"' + entry[-1] + '"\n' )

						writeHandle.close()

			# write the ground truth to disk along with the unlabelled extractions to allow easy feedback for new annotations
			logger.info( 'number of unlabelled entries = ' + str(len(listUnlabelledResult)) )
			if len(listUnlabelledResult) > 0 :
 				strFeedbackFile = strGroundTruth + '.' + strDataset + '.unlabelled.txt'
				logger.info( 'UNLABELLED : ' + strFeedbackFile )
				writeHandle = codecs.open( strFeedbackFile, 'w', 'utf-8', errors = 'replace' )

				for nIndex in range(len(listSents)) :
					writeHandle.write( listSents[nIndex] + '\n' )

					for entry in listGroundTruth :
						nIndexEntry = entry[0]
						if nIndexEntry > len(listSents)-1 :
							raise Exception( 'ground truth sent index out of range' )

						if nIndex == nIndexEntry :
							writeHandle.write( str(nIndexEntry) + '\t' )
							for strCol in entry[1:-1] :
								writeHandle.write( '"' + strCol + '"\t' )
							writeHandle.write( str(entry[-1]) + '\n' )

					for entry in listUnlabelledResult :
						nIndexEntry = entry[0]
						if nIndexEntry > len(listSents)-1 :
							raise Exception( 'unlabelled sent index out of range : ' + repr(entry) )

						if nIndex == nIndexEntry :
							writeHandle.write( str(nIndexEntry) + '\t' )
							for strCol in entry[1:-1] :
								writeHandle.write( '"' + strCol + '"\t' )
							writeHandle.write( entry[-1] + '\n' )

				writeHandle.close()

	except :
		logger.exception( 'eval_open_ie_results main() exception' )
		sys.stderr.flush()
		sys.stdout.flush()

		# close file handler
		if readHandle != None :
			readHandle.close()
		if writeHandle != None :
			writeHandle.close()
		logger.info( 'closed file handles' )

		sys.stdout.flush()
		sys.exit(1)

	# all done
	logger.info('finished')
	sys.stdout.flush()
	sys.exit(0);
