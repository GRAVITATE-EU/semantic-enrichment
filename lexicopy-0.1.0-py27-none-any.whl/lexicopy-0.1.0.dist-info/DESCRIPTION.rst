lexicopy project
=====================

lexicopy is a Python library that is built upon NLTK. It handles lexicon management including gazateer import and lexicon bootstrapping. Search for 'lexicopy' in pypi.python.org for lexicopy homepage and license information.

lexicopy works with Python 2.7 and has been tested on Windows 10, Windows 2012 Server, Ubuntu 14.04 LTS and Ubuntu 16.04 LTS.

Feature suggestions and/or bug reports can be sent to {lexicopy}@it-innovation.soton.ac.uk. We do not however offer any software support beyond the examples and API documentation already provided.


lexicopy user documentation
-----------------------------
https://pythonhosted.org/lexicopy/readme.html


lexicopy API documentation
----------------------------
https://pythonhosted.org/lexicopy/index.html

The software is copyright 2017 University of Southampton IT Innovation Centre, UK (http://www.it-innovation.soton.ac.uk). It was created over a 5 year period under EU FP7 projects REVEAL (grant agreement number 610928) and EU H2020 project GRAVITATE (grant agreement number 665155). This software can only be used for research, education or evaluation purposes. A free commercial license is available on request to {soton_corenlppy}@it-innovation.soton.ac.uk. The University of Southampton IT Innovation Centre is open to discussions regarding collaboration in future research projects relating to this work.


lexicopy license
----------------------------
https://pythonhosted.org/lexicopy/license.html


Python libs needed
------------------
Python libs: nltk >= 3.2, ,setuptools >= 20


